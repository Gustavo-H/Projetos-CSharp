﻿namespace jogo_Beatles
{
    partial class Jogo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Jogo));
            this.btnPassar = new System.Windows.Forms.Button();
            this.progresso = new System.Windows.Forms.ProgressBar();
            this.btnRingoDP = new System.Windows.Forms.Button();
            this.btnGeorgeDP = new System.Windows.Forms.Button();
            this.btnPaulDP = new System.Windows.Forms.Button();
            this.btnRingoAP = new System.Windows.Forms.Button();
            this.btnGeorgeAP = new System.Windows.Forms.Button();
            this.btnPaulAP = new System.Windows.Forms.Button();
            this.btnJohnAP = new System.Windows.Forms.Button();
            this.btnJohnDP = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTempo = new System.Windows.Forms.Label();
            this.gifIdaOne = new System.Windows.Forms.PictureBox();
            this.gifIda2 = new System.Windows.Forms.PictureBox();
            this.gifVolta = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gifIdaOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gifIda2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gifVolta)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPassar
            // 
            this.btnPassar.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPassar.ForeColor = System.Drawing.Color.Black;
            this.btnPassar.Location = new System.Drawing.Point(322, 375);
            this.btnPassar.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnPassar.Name = "btnPassar";
            this.btnPassar.Size = new System.Drawing.Size(103, 39);
            this.btnPassar.TabIndex = 1;
            this.btnPassar.Text = "PASSAR";
            this.btnPassar.UseVisualStyleBackColor = true;
            this.btnPassar.Click += new System.EventHandler(this.btnPassar_Click);
            // 
            // progresso
            // 
            this.progresso.Location = new System.Drawing.Point(437, 375);
            this.progresso.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.progresso.Maximum = 400;
            this.progresso.Name = "progresso";
            this.progresso.Size = new System.Drawing.Size(194, 39);
            this.progresso.TabIndex = 2;
            // 
            // btnRingoDP
            // 
            this.btnRingoDP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRingoDP.BackgroundImage")));
            this.btnRingoDP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRingoDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRingoDP.ForeColor = System.Drawing.Color.Transparent;
            this.btnRingoDP.Location = new System.Drawing.Point(874, 297);
            this.btnRingoDP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnRingoDP.Name = "btnRingoDP";
            this.btnRingoDP.Size = new System.Drawing.Size(80, 80);
            this.btnRingoDP.TabIndex = 15;
            this.btnRingoDP.Text = "54";
            this.btnRingoDP.UseVisualStyleBackColor = true;
            this.btnRingoDP.Visible = false;
            this.btnRingoDP.Click += new System.EventHandler(this.volta);
            // 
            // btnGeorgeDP
            // 
            this.btnGeorgeDP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeorgeDP.BackgroundImage")));
            this.btnGeorgeDP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGeorgeDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeorgeDP.ForeColor = System.Drawing.Color.Transparent;
            this.btnGeorgeDP.Location = new System.Drawing.Point(874, 201);
            this.btnGeorgeDP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnGeorgeDP.Name = "btnGeorgeDP";
            this.btnGeorgeDP.Size = new System.Drawing.Size(80, 80);
            this.btnGeorgeDP.TabIndex = 14;
            this.btnGeorgeDP.Text = "54";
            this.btnGeorgeDP.UseVisualStyleBackColor = true;
            this.btnGeorgeDP.Visible = false;
            this.btnGeorgeDP.Click += new System.EventHandler(this.volta);
            // 
            // btnPaulDP
            // 
            this.btnPaulDP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPaulDP.BackgroundImage")));
            this.btnPaulDP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPaulDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaulDP.ForeColor = System.Drawing.Color.Transparent;
            this.btnPaulDP.Location = new System.Drawing.Point(874, 105);
            this.btnPaulDP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnPaulDP.Name = "btnPaulDP";
            this.btnPaulDP.Size = new System.Drawing.Size(80, 80);
            this.btnPaulDP.TabIndex = 13;
            this.btnPaulDP.Text = "54";
            this.btnPaulDP.UseVisualStyleBackColor = true;
            this.btnPaulDP.Visible = false;
            this.btnPaulDP.Click += new System.EventHandler(this.volta);
            // 
            // btnRingoAP
            // 
            this.btnRingoAP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRingoAP.BackgroundImage")));
            this.btnRingoAP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRingoAP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRingoAP.ForeColor = System.Drawing.Color.Transparent;
            this.btnRingoAP.Location = new System.Drawing.Point(0, 297);
            this.btnRingoAP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnRingoAP.Name = "btnRingoAP";
            this.btnRingoAP.Size = new System.Drawing.Size(80, 80);
            this.btnRingoAP.TabIndex = 11;
            this.btnRingoAP.Text = "54";
            this.btnRingoAP.UseVisualStyleBackColor = true;
            this.btnRingoAP.Click += new System.EventHandler(this.ida);
            // 
            // btnGeorgeAP
            // 
            this.btnGeorgeAP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGeorgeAP.BackgroundImage")));
            this.btnGeorgeAP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGeorgeAP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeorgeAP.ForeColor = System.Drawing.Color.Transparent;
            this.btnGeorgeAP.Location = new System.Drawing.Point(0, 201);
            this.btnGeorgeAP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnGeorgeAP.Name = "btnGeorgeAP";
            this.btnGeorgeAP.Size = new System.Drawing.Size(80, 80);
            this.btnGeorgeAP.TabIndex = 10;
            this.btnGeorgeAP.Text = "54";
            this.btnGeorgeAP.UseVisualStyleBackColor = true;
            this.btnGeorgeAP.Click += new System.EventHandler(this.ida);
            // 
            // btnPaulAP
            // 
            this.btnPaulAP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPaulAP.BackgroundImage")));
            this.btnPaulAP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPaulAP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaulAP.ForeColor = System.Drawing.Color.Transparent;
            this.btnPaulAP.Location = new System.Drawing.Point(0, 105);
            this.btnPaulAP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnPaulAP.Name = "btnPaulAP";
            this.btnPaulAP.Size = new System.Drawing.Size(80, 80);
            this.btnPaulAP.TabIndex = 9;
            this.btnPaulAP.Text = "54";
            this.btnPaulAP.UseVisualStyleBackColor = true;
            this.btnPaulAP.Click += new System.EventHandler(this.ida);
            // 
            // btnJohnAP
            // 
            this.btnJohnAP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnJohnAP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnJohnAP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJohnAP.BackgroundImage")));
            this.btnJohnAP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnJohnAP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJohnAP.ForeColor = System.Drawing.Color.Transparent;
            this.btnJohnAP.Location = new System.Drawing.Point(0, 9);
            this.btnJohnAP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnJohnAP.Name = "btnJohnAP";
            this.btnJohnAP.Size = new System.Drawing.Size(80, 80);
            this.btnJohnAP.TabIndex = 16;
            this.btnJohnAP.Text = "57";
            this.btnJohnAP.UseVisualStyleBackColor = false;
            this.btnJohnAP.Click += new System.EventHandler(this.ida);
            // 
            // btnJohnDP
            // 
            this.btnJohnDP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJohnDP.BackgroundImage")));
            this.btnJohnDP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnJohnDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJohnDP.ForeColor = System.Drawing.Color.Transparent;
            this.btnJohnDP.Location = new System.Drawing.Point(874, 9);
            this.btnJohnDP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnJohnDP.Name = "btnJohnDP";
            this.btnJohnDP.Size = new System.Drawing.Size(80, 80);
            this.btnJohnDP.TabIndex = 17;
            this.btnJohnDP.Text = "54";
            this.btnJohnDP.UseVisualStyleBackColor = true;
            this.btnJohnDP.Visible = false;
            this.btnJohnDP.Click += new System.EventHandler(this.volta);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(438, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 22);
            this.label1.TabIndex = 18;
            this.label1.Text = "TEMPO";
            // 
            // lblTempo
            // 
            this.lblTempo.AutoSize = true;
            this.lblTempo.BackColor = System.Drawing.Color.Transparent;
            this.lblTempo.Font = new System.Drawing.Font("Bernard MT Condensed", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempo.ForeColor = System.Drawing.SystemColors.Control;
            this.lblTempo.Location = new System.Drawing.Point(444, 32);
            this.lblTempo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTempo.Name = "lblTempo";
            this.lblTempo.Size = new System.Drawing.Size(56, 44);
            this.lblTempo.TabIndex = 19;
            this.lblTempo.Text = "30";
            // 
            // gifIdaOne
            // 
            this.gifIdaOne.BackColor = System.Drawing.Color.Transparent;
            this.gifIdaOne.Image = ((System.Drawing.Image)(resources.GetObject("gifIdaOne.Image")));
            this.gifIdaOne.Location = new System.Drawing.Point(255, 198);
            this.gifIdaOne.Name = "gifIdaOne";
            this.gifIdaOne.Size = new System.Drawing.Size(55, 55);
            this.gifIdaOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.gifIdaOne.TabIndex = 20;
            this.gifIdaOne.TabStop = false;
            this.gifIdaOne.Visible = false;
            // 
            // gifIda2
            // 
            this.gifIda2.BackColor = System.Drawing.Color.Transparent;
            this.gifIda2.Image = ((System.Drawing.Image)(resources.GetObject("gifIda2.Image")));
            this.gifIda2.Location = new System.Drawing.Point(255, 175);
            this.gifIda2.Name = "gifIda2";
            this.gifIda2.Size = new System.Drawing.Size(55, 100);
            this.gifIda2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.gifIda2.TabIndex = 21;
            this.gifIda2.TabStop = false;
            // 
            // gifVolta
            // 
            this.gifVolta.BackColor = System.Drawing.Color.Transparent;
            this.gifVolta.Image = ((System.Drawing.Image)(resources.GetObject("gifVolta.Image")));
            this.gifVolta.Location = new System.Drawing.Point(645, 201);
            this.gifVolta.Name = "gifVolta";
            this.gifVolta.Size = new System.Drawing.Size(55, 55);
            this.gifVolta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.gifVolta.TabIndex = 22;
            this.gifVolta.TabStop = false;
            this.gifVolta.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(10, 391);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 22);
            this.label2.TabIndex = 23;
            this.label2.Text = "    ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Jogo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(952, 423);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gifVolta);
            this.Controls.Add(this.gifIda2);
            this.Controls.Add(this.gifIdaOne);
            this.Controls.Add(this.lblTempo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnJohnDP);
            this.Controls.Add(this.btnJohnAP);
            this.Controls.Add(this.btnRingoDP);
            this.Controls.Add(this.btnGeorgeDP);
            this.Controls.Add(this.btnPaulDP);
            this.Controls.Add(this.btnRingoAP);
            this.Controls.Add(this.btnGeorgeAP);
            this.Controls.Add(this.btnPaulAP);
            this.Controls.Add(this.progresso);
            this.Controls.Add(this.btnPassar);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.MaximizeBox = false;
            this.Name = "Jogo";
            this.Text = "Jogo";
            this.Load += new System.EventHandler(this.Jogo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gifIdaOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gifIda2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gifVolta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPassar;
        private System.Windows.Forms.ProgressBar progresso;
        private System.Windows.Forms.Button btnRingoDP;
        private System.Windows.Forms.Button btnGeorgeDP;
        private System.Windows.Forms.Button btnPaulDP;
        private System.Windows.Forms.Button btnRingoAP;
        private System.Windows.Forms.Button btnGeorgeAP;
        private System.Windows.Forms.Button btnPaulAP;
        private System.Windows.Forms.Button btnJohnAP;
        private System.Windows.Forms.Button btnJohnDP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTempo;
        private System.Windows.Forms.PictureBox gifIdaOne;
        private System.Windows.Forms.PictureBox gifIda2;
        private System.Windows.Forms.PictureBox gifVolta;
        private System.Windows.Forms.Label label2;

    }
}
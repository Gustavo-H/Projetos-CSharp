-------------------------------------------------------------------------------
--Povoando Tabela Curso--------------------------------------------------------
-------------------------------------------------------------------------------
Insert Into TB_Curso(Nm_Curso, Ds_Abrev_Curso, Qt_Semestres) 
	Values('ANALISE E DESENVOLVIMENTO DE SISTEMAS','ADS',6);
Insert Into TB_Curso(Nm_Curso, Ds_Abrev_Curso, Qt_Semestres) 
	Values('PROCESSOS QUIMICOS','PQ',7);

-------------------------------------------------------------------------------
--Povoando Tabela Professor----------------------------------------------------
-------------------------------------------------------------------------------
Insert Into TB_Professor(Nm_Professor, Ra_Professor, Ds_Email_Professor) 
	Values ('IRAPUAN JUNIOR','1234546', 'QWERTY@YTREWQ');
Insert Into TB_Professor(Nm_Professor, Ra_Professor, Ds_Email_Professor) 
	Values ('CARLINHOS PARMERA','1234546', 'QWERTY@YTREWQ');
Insert Into TB_Professor(Nm_Professor, Ra_Professor, Ds_Email_Professor) 
	Values ('FERNANDO SATORSULA','1234546', 'QWERTY@YTREWQ');
Insert Into TB_Professor(Nm_Professor, Ra_Professor, Ds_Email_Professor) 
	Values ('WENDEL PINHEIRO','1234546', 'QWERTY@YTREWQ');
Insert Into TB_Professor(Nm_Professor, Ra_Professor, Ds_Email_Professor) 
	Values ('VITOR BRANDI','1234546', 'QWERTY@YTREWQ');

-------------------------------------------------------------------------------
--Povoando Tabela Materia------------------------------------------------------
-------------------------------------------------------------------------------
Insert Into TB_Materia(Nm_Materia, Ds_Abrev_Materia, Id_Curso, Ds_Semestre) 
	Values('BANCO DE DADOS II','BD2', 1, 3);
Insert Into TB_Materia(Nm_Materia, Ds_Abrev_Materia, Id_Curso, Ds_Semestre) 
	Values('LINGUAGEM DE PROGRAMA��O II','LP2', 1, 3); 
Insert Into TB_Materia(Nm_Materia, Ds_Abrev_Materia, Id_Curso, Ds_Semestre) 
	Values('ENGENHARIA DE SOFTWARE','ESW', 1, 3); 
Insert Into TB_Materia(Nm_Materia, Ds_Abrev_Materia, Id_Curso, Ds_Semestre) 
	Values('ANALISE ORIENTADA A OBJETO','AOO', 1, 3);
Insert Into TB_Materia(Nm_Materia, Ds_Abrev_Materia, Id_Curso, Ds_Semestre) 
	Values('ESTRUTURA DE DADOS II','ED2', 1, 3); 

-------------------------------------------------------------------------------
--Povoando Tabela Sala---------------------------------------------------------
-------------------------------------------------------------------------------
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 1','labInfo1');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 2','labInfo2');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 3','labInfo3');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 4','labInfo4');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 5','labInfo5');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 6','labInfo6');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 7','labInfo7');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Informatica 8','labInfo8');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Quimica 1','labQui1');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Laboratorio de Quimica 2','labQui2');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Sala de Aula 2','Sala 2');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Sala de Aula 7','Sala 7');
Insert Into TB_Sala (Nm_Sala, Ds_Abrev_Sala) 
	Values ('Sala de Aula 8','Sala 8');

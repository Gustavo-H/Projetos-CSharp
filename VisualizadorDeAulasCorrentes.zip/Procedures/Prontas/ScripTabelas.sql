Drop Table If Exists TB_Historico;
Drop Table If Exists TB_Aula;
Drop Table If Exists TB_Sala;
Drop Table If Exists TB_Materia;
Drop Table If Exists TB_Professor;
Drop Table If Exists TB_Curso;

-------------------------------------------------------------------------------
--Criando Tabela Professor-----------------------------------------------------
-------------------------------------------------------------------------------
Create Table TB_Professor(
	Id_Professor       Int          Not Null Identity(1,1),
	Nm_Professor       Varchar(100) Not Null,
	Ra_Professor       Varchar(7)   Not Null,
	Ds_Email_Professor Varchar(100) Not Null,
Primary Key(Id_Professor));

-------------------------------------------------------------------------------
--Criando Tabela Curso---------------------------------------------------------
-------------------------------------------------------------------------------
Create Table TB_Curso(
	Id_Curso       Int          Not Null Identity(1,1),
	Nm_Curso       Varchar(100) Not Null,
	Ds_Abrev_Curso Varchar(10)  Not Null,
	Qt_Semestres   Int          Not Null
Primary Key(Id_Curso));

-------------------------------------------------------------------------------
--Criando Tabela Materia-------------------------------------------------------
-------------------------------------------------------------------------------
Create Table TB_Materia(
	Id_Materia       Int          Not Null Identity(1,1),
	Nm_Materia       Varchar(100) Not Null,	
	Ds_Abrev_Materia Varchar(7)   Not Null,
	Ds_Semestre       Int          Not Null, 
	Id_Curso         Int          Not Null
Primary Key (Id_Materia));

Alter Table TB_Materia 
	Add Constraint Fk_Id_Curso_TB_Curso
	Foreign Key (Id_Curso) References TB_Curso (Id_Curso)

-------------------------------------------------------------------------------
--Criando Tabela Sala----------------------------------------------------------
-------------------------------------------------------------------------------
Create Table TB_Sala(
	Id_Sala       Int         Not Null Identity(1,1),
	Nm_Sala       Varchar(50) Not Null,	
	Ds_Abrev_Sala Varchar(10)
Primary Key (Id_Sala));

-------------------------------------------------------------------------------
--Criando Tabela Aula----------------------------------------------------------
-------------------------------------------------------------------------------		
Create Table TB_Aula(
	Id_Aula      Int      Not Null Identity(1,1),
	Id_Sala      Int      Not Null,
	Id_Professor Int      Not Null,
	Id_Materia   Int      Not Null,
	data_inicio  Datetime Not Null,
	data_fim     Datetime Not Null,
Primary Key (Id_Aula));

Alter Table TB_Aula
	Add Constraint FK_Id_Sala_TB_Sala  
		Foreign Key  (Id_Sala) References TB_Sala (Id_Sala)

Alter Table TB_Aula
	Add Constraint FK_Id_Professor_TB_Professor  
		Foreign Key (Id_Professor) References TB_Professor (Id_Professor)

Alter Table TB_Aula
	Add Constraint FK_Id_Materia_TB_Materia  
		Foreign Key (Id_Materia)   References TB_Materia (Id_Materia)


-------------------------------------------------------------------------------
--Criando Tabela Historico-----------------------------------------------------
-------------------------------------------------------------------------------
Create Table TB_Historico(
	Id_Historico Int      Not Null Identity(1,1),
	Id_Aula      Int      Not Null,
	Id_Sala      Int      Not Null,
	Id_Professor Int      Not Null,
	Id_Materia   Int      Not Null,
	data_inicio  Datetime Not Null,
	data_fim     Datetime Not Null,
Primary Key (Id_Historico));

Alter Table TB_Historico
	Add Constraint FK_Id_Aula_TB_Aula  
		Foreign Key (Id_Aula)   References TB_Aula (Id_Aula)







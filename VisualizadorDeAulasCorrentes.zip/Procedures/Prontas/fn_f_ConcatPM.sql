	Drop Function If Exists fn_f_ConcatPM;
Go
Create Function fn_f_ConcatPM(@p_NmProfessor Varchar(30), @p_NmMateria Varchar(30))
Returns Varchar(100)
Begin
	Declare @pRetorno as Varchar(100);	 
	Set @pRetorno = Concat('Professor: ',@p_NmProfessor,'|', 'Materia: ', @p_NmMateria);
	Return @pRetorno;
End;

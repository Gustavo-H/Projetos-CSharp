Drop Procedure If Exists sp_DelAula;
Go
Create Procedure sp_DelAula(@pId As Int)
As
Begin
	Delete From TB_Aula Where Id_Aula=@pId;
End
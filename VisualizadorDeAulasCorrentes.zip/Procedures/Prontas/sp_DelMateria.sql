Drop Procedure If Exists sp_DelMateria;
Go
Create Procedure sp_DelMateria(@pId As Int)
As
Begin
	Delete From TB_Materia Where Id_Materia=@pId;
End
Drop Procedure If Exists sp_DelProfessor;
Go
Create Procedure sp_DelProfessor(@pId As Int)
As
Begin
	Delete From TB_Professor Where Id_Professor=@pId;
End;


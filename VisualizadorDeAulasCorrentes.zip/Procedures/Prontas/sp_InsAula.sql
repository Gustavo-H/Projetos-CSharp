Drop Procedure If Exists sp_InsAula;
Go
Create Procedure sp_InsAula(@pIdSala Int, @pIdMateria Int, @pIdProfessor Int, 
							@pDataInicio DateTime, @pDataFim DateTime)
As
Begin
	Insert Into TB_Aula (Id_Sala, Id_Materia, Id_Professor, data_inicio, data_fim)
		Values(@pIdSala, @pIdMateria, @pIdProfessor, @pDataInicio, @pDataFim);
End;
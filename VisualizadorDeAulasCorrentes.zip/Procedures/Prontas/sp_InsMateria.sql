Drop Procedure If Exists sp_InsMateria;
Go
Create Procedure sp_InsMateria(
	@pNome As Varchar(100), @pAbrev As Varchar(7),
	@pCurso As Int, @pSemestre As Int)  
As
	Begin
		Insert Into TB_Materia (Ds_Abrev_Materia, Ds_Semeste, Id_Curso, Nm_Materia)
			Values (@pAbrev, @pSemestre, @pCurso, @pNome); 
End;
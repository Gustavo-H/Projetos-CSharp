Drop Procedure If Exists sp_InsProfessor;
Go
Create Procedure sp_InsProfessor(     
       @pNome As Varchar(100), @pRa As Varchar(7),
       @pEmail As Varchar(100))  
As
Begin
Insert Into TB_Professor (Nm_Professor, Ds_Email_Professor, Ra_Professor)
	Values (@pNome, @pEmail, @pRa);
End;
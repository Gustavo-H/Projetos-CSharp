Drop Procedure If Exists sp_SelAula;
Go
Create Procedure sp_SelAula (@pId As Int)
As
Begin
	Select P.Nm_Professor As Professor, M.Nm_Materia As Materia,
		S.Nm_Sala As Sala, A.data_inicio As DataInicio, A.data_fim As DataFim
	From TB_Aula As A
	Inner Join TB_Professor As P On A.Id_Professor = P.Id_Professor
	Inner Join TB_Materia As M On A.Id_Materia = M.Id_Materia
	Inner Join TB_Sala As S On A.Id_Sala = S.Id_Sala
	Where A.Id_Aula = @pId;
End;
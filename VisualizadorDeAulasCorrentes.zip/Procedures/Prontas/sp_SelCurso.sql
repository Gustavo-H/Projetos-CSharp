Drop Procedure If Exists sp_SelCurso;
Go
Create Procedure sp_SelCurso
As
Begin
	Select Id_Curso As Id, Ds_Abrev_Curso As Abrev, Nm_Curso As Nome
	From TB_Curso
	Order By Id_Curso;
End;
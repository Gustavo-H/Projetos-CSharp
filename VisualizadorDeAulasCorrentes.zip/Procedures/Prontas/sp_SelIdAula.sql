Drop Procedure If Exists sp_SelIdAula;
Go
Create Procedure sp_SelIdAula (@pDataAtual As DateTime2)
As
Begin	
	Select A.Id_Aula As Id
	From TB_Aula As A	
	Where @pDataAtual Between Convert(datetime2, A.data_inicio) And Convert(datetime2, A.data_fim)	
End;
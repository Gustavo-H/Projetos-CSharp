Drop Procedure If Exists sp_SelMaiorIdMateria;
Go
Create Procedure sp_SelMaiorIdMateria
As
Begin
	Select Max(Id_Materia) As 'Id'
	From TB_Materia	
End;


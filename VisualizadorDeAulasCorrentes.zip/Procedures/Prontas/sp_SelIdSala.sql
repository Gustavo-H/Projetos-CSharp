Drop Procedure If Exists sp_SelIdSala;
Go
Create Procedure sp_SelIdSala
As
Begin	
	Select Count(S.Id_Sala) As TotalId
	From TB_Sala As S
End;

Drop Procedure If Exists sp_SelMaiorSemestre;
Go
Create Procedure sp_SelMaiorSemestre(@pId Int)
As
Begin	
	Select C.Qt_Semestres As Maior
	From TB_Curso As C
	Where C.Id_Curso = @pId;	
End;


Drop Procedure If Exists sp_SelMatEspCurSem;
Go
Create Procedure sp_SelMatEspCurSem(@pSemestre Int, @pCurso Int)
As
Begin
	Select M.Nm_Materia As Nome, M.Ds_Abrev_Materia As Abrev, M.Id_Materia As Id	 
	From TB_Materia As M	 
	Where M.Ds_Semestre=@pSemestre 
	And M.Id_Curso = @pCurso;
End;


Drop Procedure If Exists sp_SelMateriaEspecifica;
Go
Create Procedure sp_SelMateriaEspecifica(@pId Int)
As
Begin
	Select M.Nm_Materia As Nome, M.Ds_Abrev_Materia As Abrev, 
		M.Ds_Semeste As Semestre, C.Ds_Abrev_Curso As Curso, C.Id_Curso As IdCurso
	From TB_Materia As M
	Inner Join TB_Curso As C On M.Id_Curso = C.Id_Curso 
	Where M.Id_Materia=@pId
End;




Drop Procedure If Exists sp_SelMaterias;
Go
Create Procedure sp_SelMaterias
As
Begin
	Select Id_Materia As Id, Nm_Materia As Nome, Ds_Abrev_Materia As Abrev
		From TB_Materia As M 		
		Order By Ds_Abrev_Materia
End;
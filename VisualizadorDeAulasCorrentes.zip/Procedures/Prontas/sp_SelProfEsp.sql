Drop Procedure If Exists sp_SelProfEsp;
Go
Create Procedure sp_SelProfEsp(@pDataInicio As DateTime2, @pDataFim As DateTime2)
As
Begin
	Select P.Id_Professor As 'Id', P.Nm_Professor As 'Nome'			 
	From TB_Professor As P		 
	Where P.Id_Professor Not In 
		(Select Id_Professor From TB_Aula As A
			Where A.data_inicio = @pDataInicio
			Or A.data_fim = @pDataFim)
End;
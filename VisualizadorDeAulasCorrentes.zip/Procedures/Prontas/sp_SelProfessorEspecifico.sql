Drop Procedure If Exists sp_SelProfessorEspecifico;
Go
Create Procedure sp_SelProfessorEspecifico( @pId As Int)
As
Begin
	Select Nm_Professor As Nome, Ds_Email_Professor As Email, Ra_Professor As Ra
	From TB_Professor
	Where Id_Professor = @pId;
End;
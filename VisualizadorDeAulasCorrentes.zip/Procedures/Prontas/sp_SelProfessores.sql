Drop Procedure If Exists sp_SelProfessores;
Go
Create Procedure sp_SelProfessores
As
Begin
	Select Id_Professor As Id, Nm_Professor As Nome 
	From TB_Professor
	Order By Nome;
End
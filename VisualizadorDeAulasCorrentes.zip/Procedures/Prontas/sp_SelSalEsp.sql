Drop Procedure If Exists sp_SelSalEsp;
Go
Create Procedure sp_SelSalEsp(@pDataInicio As DateTime2, @pDataFim As DateTime2)
As
Begin
	Select S.Id_Sala As 'Id', S.Nm_Sala As 'Nome', S.Ds_Abrev_Sala As 'Abrev'			 
	From TB_Sala As S	 
	Where S.Id_Sala Not In 
		(Select A.Id_Sala From TB_Aula As A
			Where A.data_inicio = @pDataInicio
			Or A.data_fim = @pDataFim)
End;
Drop Procedure If Exists sp_SelSalasDispAgora;
Go
Create Procedure sp_SelSalasDispAgora (@pDataAtual As DateTime2)
As
Begin	
	Select S.Ds_Abrev_Sala As Sala
	From TB_Sala As S		
	Where S.Id_Sala Not In 
	(Select A.Id_Sala From TB_Aula As A					
		Where @pDataAtual Between Convert(datetime2, A.data_inicio) And Convert(datetime2, A.data_fim))
End;
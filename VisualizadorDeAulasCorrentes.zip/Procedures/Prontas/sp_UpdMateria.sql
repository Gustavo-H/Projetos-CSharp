Drop Procedure If Exists sp_UpdMateria;
Go
Create Procedure sp_UpdMateria(
	@pNome As Varchar(100), @pAbrev As Varchar(7),
	@pCurso As Int, @pSemestre As Int, @pId As Int)  
As
Begin
	Update TB_Materia Set Nm_Materia = @pNome, Ds_Abrev_Materia=@pAbrev, 
	Ds_Semeste=@pSemestre, Id_Curso=@pCurso WHERE Id_Materia=@pId;
End;
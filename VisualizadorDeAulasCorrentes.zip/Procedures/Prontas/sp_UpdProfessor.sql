Drop Procedure If Exists sp_UpdProfessor;
Go
Create Procedure sp_UpdProfessor(
       @pId As Int,  @pNome As Varchar(100),
       @pRa As Varchar(7), @pEmail As Varchar(100))
As
Begin
Update TB_Professor Set Nm_Professor=@pNome, Ds_Email_Professor=@pEmail, Ra_Professor = @pRa
	Where Id_Professor=@pId;
End;
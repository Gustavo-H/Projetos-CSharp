﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace TIND
{
    class Aula
    {
        private int mIdAula;
        private int mIdSala;
        private int mIdProfessor;
        private int mIdMateria;
        private DateTime mDataInicio;
        private DateTime mDataFim;        
        private string mNomeSala;
        private string mNomeProfessor;
        private string mNomeMateria;

        public int idAula
        {
            get { return mIdAula; }
            set { mIdAula = value; }
        }
        public int idSala
        {
            get { return mIdSala; }
            set { mIdSala = value; }
        }
        public int idProfessor
        {
            get { return mIdProfessor; }
            set { mIdProfessor = value; }
        }
        public int idMateria
        {
            get { return mIdMateria; }
            set { mIdMateria = value; }
        }
        public DateTime dataInicio
        {
            get { return mDataInicio; }
            set { mDataInicio = value; }
        }
        public DateTime dataFim
        {
            get { return mDataFim; }
            set { mDataFim = value; }
        }
        public string nomeSala
        {
            get { return mNomeSala; }
            set { mNomeSala = value; }
        }
        public string nomeProfessor
        {
            get { return mNomeProfessor; }
            set { mNomeProfessor = value; }
        }
        public string nomeMateria
        {
            get { return mNomeMateria; }
            set { mNomeMateria = value; }
        }
        

        public static string setAula(Aula aula)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_InsAula", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pIdSala", aula.idSala);
                cmd.Parameters.AddWithValue("@pIdMateria", aula.idMateria);
                cmd.Parameters.AddWithValue("@pIdProfessor", aula.idProfessor);
                cmd.Parameters.AddWithValue("@pDataInicio", aula.dataInicio);
                cmd.Parameters.AddWithValue("@pDataFim", aula.dataFim);
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                conexao.desconectar();
                return ("");
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }           
        }

        public static Aula getAula(int id)
        {
            Aula aula = new Aula();
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_SelAulaId", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", id);
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                aula.nomeMateria = dr["Materia"].ToString();
                aula.nomeProfessor = dr["Professor"].ToString();
                aula.nomeSala = dr["Sala"].ToString();
                aula.dataInicio = Convert.ToDateTime(dr["DataInicio"].ToString());
                aula.dataFim = Convert.ToDateTime(dr["DataFim"].ToString());
                dr.Close();
                conexao.desconectar();
                return aula;
            }
            catch
            {
                return null;
            } 
        }

        public static string delAula(int id)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_DelAula", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", id);
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                return ("");
            }
            catch (Exception ex)
            {
                return (ex.ToString());
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TIND
{
    class Conexao
    {
        public SqlConnection conexao = new SqlConnection();

        public void conectar()
        {
            conexao.ConnectionString = "Server = GH-PC\\SQLEXPRESS01; Database = tindIfsp; Uid= ifsp; trusted_connection=true; timeout=10;";              
            conexao.Open();
        }

        public void desconectar()
        {
            conexao.Close();
        }
    }
}

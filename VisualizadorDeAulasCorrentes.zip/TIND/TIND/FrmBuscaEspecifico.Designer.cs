﻿namespace TIND
{
    partial class FrmBuscaEspecifico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBuscaEspecifico));
            this.lblIFSP = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtNomeBusca = new System.Windows.Forms.TextBox();
            this.lstNomes = new System.Windows.Forms.ListBox();
            this.lstSemestre = new System.Windows.Forms.ListBox();
            this.lstCurso = new System.Windows.Forms.ListBox();
            this.chkNome = new System.Windows.Forms.CheckBox();
            this.chkCurso = new System.Windows.Forms.CheckBox();
            this.chkSemestre = new System.Windows.Forms.CheckBox();
            this.btnBuscar = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblIFSP
            // 
            this.lblIFSP.ActiveBorderThickness = 1;
            this.lblIFSP.ActiveCornerRadius = 20;
            this.lblIFSP.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.ActiveForecolor = System.Drawing.Color.Black;
            this.lblIFSP.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.lblIFSP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lblIFSP.BackgroundImage")));
            this.lblIFSP.ButtonText = "Instituto Federal de São Paulo - Campus Capivari";
            this.lblIFSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIFSP.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIFSP.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleBorderThickness = 1;
            this.lblIFSP.IdleCornerRadius = 20;
            this.lblIFSP.IdleFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleForecolor = System.Drawing.Color.Transparent;
            this.lblIFSP.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.Location = new System.Drawing.Point(150, 19);
            this.lblIFSP.Margin = new System.Windows.Forms.Padding(5);
            this.lblIFSP.Name = "lblIFSP";
            this.lblIFSP.Size = new System.Drawing.Size(539, 41);
            this.lblIFSP.TabIndex = 204;
            this.lblIFSP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIFSP.Click += new System.EventHandler(this.lblIFSP_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.panel1.Controls.Add(this.lblIFSP);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(838, 79);
            this.panel1.TabIndex = 240;
            // 
            // txtNomeBusca
            // 
            this.txtNomeBusca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeBusca.ForeColor = System.Drawing.Color.DarkGreen;
            this.txtNomeBusca.Location = new System.Drawing.Point(274, 88);
            this.txtNomeBusca.Name = "txtNomeBusca";
            this.txtNomeBusca.Size = new System.Drawing.Size(307, 26);
            this.txtNomeBusca.TabIndex = 1;
            this.txtNomeBusca.Text = "Digite Um Nome Para Busca";
            this.txtNomeBusca.Click += new System.EventHandler(this.cliqueTxtNome);
            this.txtNomeBusca.TextChanged += new System.EventHandler(this.txtNomeBusca_TextChanged);
            // 
            // lstNomes
            // 
            this.lstNomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstNomes.FormattingEnabled = true;
            this.lstNomes.ItemHeight = 20;
            this.lstNomes.Location = new System.Drawing.Point(10, 224);
            this.lstNomes.Name = "lstNomes";
            this.lstNomes.Size = new System.Drawing.Size(814, 264);
            this.lstNomes.TabIndex = 237;
            // 
            // lstSemestre
            // 
            this.lstSemestre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstSemestre.ForeColor = System.Drawing.Color.DarkGreen;
            this.lstSemestre.FormattingEnabled = true;
            this.lstSemestre.ItemHeight = 20;
            this.lstSemestre.Location = new System.Drawing.Point(274, 126);
            this.lstSemestre.Name = "lstSemestre";
            this.lstSemestre.Size = new System.Drawing.Size(307, 24);
            this.lstSemestre.TabIndex = 249;
            // 
            // lstCurso
            // 
            this.lstCurso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCurso.ForeColor = System.Drawing.Color.DarkGreen;
            this.lstCurso.FormattingEnabled = true;
            this.lstCurso.ItemHeight = 20;
            this.lstCurso.Location = new System.Drawing.Point(274, 165);
            this.lstCurso.Name = "lstCurso";
            this.lstCurso.Size = new System.Drawing.Size(307, 24);
            this.lstCurso.TabIndex = 250;
            // 
            // chkNome
            // 
            this.chkNome.AutoSize = true;
            this.chkNome.Checked = true;
            this.chkNome.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkNome.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkNome.Location = new System.Drawing.Point(12, 90);
            this.chkNome.Name = "chkNome";
            this.chkNome.Size = new System.Drawing.Size(152, 24);
            this.chkNome.TabIndex = 253;
            this.chkNome.Text = "Buscar Por Nome";
            this.chkNome.UseVisualStyleBackColor = true;
            this.chkNome.CheckedChanged += new System.EventHandler(this.chkNome_CheckedChanged);
            // 
            // chkCurso
            // 
            this.chkCurso.AutoSize = true;
            this.chkCurso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCurso.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkCurso.Location = new System.Drawing.Point(12, 165);
            this.chkCurso.Name = "chkCurso";
            this.chkCurso.Size = new System.Drawing.Size(152, 24);
            this.chkCurso.TabIndex = 254;
            this.chkCurso.Text = "Buscar Por Curso";
            this.chkCurso.UseVisualStyleBackColor = true;
            this.chkCurso.CheckedChanged += new System.EventHandler(this.chkCurso_CheckedChanged);
            // 
            // chkSemestre
            // 
            this.chkSemestre.AutoSize = true;
            this.chkSemestre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSemestre.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkSemestre.Location = new System.Drawing.Point(12, 126);
            this.chkSemestre.Name = "chkSemestre";
            this.chkSemestre.Size = new System.Drawing.Size(179, 24);
            this.chkSemestre.TabIndex = 255;
            this.chkSemestre.Text = "Buscar Por Semestre";
            this.chkSemestre.UseVisualStyleBackColor = true;
            this.chkSemestre.CheckedChanged += new System.EventHandler(this.chkSemestre_CheckedChanged);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Image = ((System.Drawing.Image)(resources.GetObject("btnBuscar.Image")));
            this.btnBuscar.Location = new System.Drawing.Point(801, 84);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(2);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(35, 30);
            this.btnBuscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnBuscar.TabIndex = 256;
            this.btnBuscar.TabStop = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(646, 96);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(55, 54);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 257;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(642, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 40);
            this.label1.TabIndex = 258;
            this.label1.Text = "Concluir \r\n Busca";
            // 
            // FrmBuscaEspecifico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(838, 500);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.chkSemestre);
            this.Controls.Add(this.chkCurso);
            this.Controls.Add(this.chkNome);
            this.Controls.Add(this.lstCurso);
            this.Controls.Add(this.lstSemestre);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtNomeBusca);
            this.Controls.Add(this.lstNomes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmBuscaEspecifico";
            this.RightToLeftLayout = true;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmBuscaEspecifico";
            this.Load += new System.EventHandler(this.FrmBuscaEspecifico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 lblIFSP;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtNomeBusca;
        private System.Windows.Forms.ListBox lstNomes;
        private System.Windows.Forms.ListBox lstSemestre;
        private System.Windows.Forms.ListBox lstCurso;
        private System.Windows.Forms.CheckBox chkNome;
        private System.Windows.Forms.CheckBox chkCurso;
        private System.Windows.Forms.CheckBox chkSemestre;
        private System.Windows.Forms.PictureBox btnBuscar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
    }
}
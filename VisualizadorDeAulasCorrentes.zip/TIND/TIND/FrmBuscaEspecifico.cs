﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TIND
{
    public partial class FrmBuscaEspecifico : Form
    {
        public FrmBuscaEspecifico()
        {
            InitializeComponent();
            telaInicio();            
        }

        private void telaInicio()
        {
            txtNomeBusca.CharacterCasing = CharacterCasing.Upper;         

        }

    

        private void chkNome_CheckedChanged(object sender, EventArgs e)
        {
            if (chkNome.Checked == true)
            {
                chkSemestre.Checked = chkCurso.Checked = false;
            }
        }

        private void cliqueTxtNome(object sender, EventArgs e)
        {
            if (txtNomeBusca.Text == "DIGITE UM NOME PARA BUSCA")
                txtNomeBusca.Text = string.Empty;

            txtNomeBusca.CharacterCasing = CharacterCasing.Upper; 
        }

        private void chkSemestre_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSemestre.Checked == true)
            {
                lstSemestre.Visible = true;
            }
            else
            {
                lstSemestre.Visible = false; 
            }
        }

        private void chkCurso_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCurso.Checked == true)
            {
                lstCurso.Visible = true;
            }
            else
            {
                lstCurso.Visible = false;
            }
        }

        private void FrmBuscaEspecifico_Load(object sender, EventArgs e)
        {
            ToolTip toolTip1 = new ToolTip();

            toolTip1.AutoPopDelay = 8000;
            toolTip1.InitialDelay = 100;
            toolTip1.ReshowDelay = 500;

            toolTip1.ShowAlways = true;

            toolTip1.SetToolTip(this.chkCurso, "Alunos Salvos No Banco");
        }

        private void txtNomeBusca_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Utilize os Campos do Lado\nEsquerdo Para Fazer a Busca\nAo Final Clique em Voltar\nPara Prosseguir Com a Ação ", "Ajuda", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void lblIFSP_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cpv.ifsp.edu.br/");
        }
    }
}

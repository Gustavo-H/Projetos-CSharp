﻿namespace TIND
{
    partial class FrmMateria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMateria));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblExcluir = new System.Windows.Forms.Label();
            this.lblCancelar = new System.Windows.Forms.Label();
            this.lblSalvar = new System.Windows.Forms.Label();
            this.lblEditar = new System.Windows.Forms.Label();
            this.lblAdicionar = new System.Windows.Forms.Label();
            this.btnExcluir = new System.Windows.Forms.PictureBox();
            this.btnCancelar = new System.Windows.Forms.PictureBox();
            this.btnSalvar = new System.Windows.Forms.PictureBox();
            this.btnEditar = new System.Windows.Forms.PictureBox();
            this.btnAdicionar = new System.Windows.Forms.PictureBox();
            this.btnBuscar = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSemestral = new System.Windows.Forms.PictureBox();
            this.lstNomes = new System.Windows.Forms.ListBox();
            this.gbxDados = new System.Windows.Forms.GroupBox();
            this.txtSemestre = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lstCurso = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAbrev = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblIFSP = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rbtAbrev = new System.Windows.Forms.RadioButton();
            this.rbtNome = new System.Windows.Forms.RadioButton();
            this.lblMessagem = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnExcluir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancelar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSalvar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEditar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdicionar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSemestral)).BeginInit();
            this.gbxDados.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblExcluir);
            this.groupBox1.Controls.Add(this.lblCancelar);
            this.groupBox1.Controls.Add(this.lblSalvar);
            this.groupBox1.Controls.Add(this.lblEditar);
            this.groupBox1.Controls.Add(this.lblAdicionar);
            this.groupBox1.Controls.Add(this.btnExcluir);
            this.groupBox1.Controls.Add(this.btnCancelar);
            this.groupBox1.Controls.Add(this.btnSalvar);
            this.groupBox1.Controls.Add(this.btnEditar);
            this.groupBox1.Controls.Add(this.btnAdicionar);
            this.groupBox1.Controls.Add(this.btnBuscar);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnSemestral);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.groupBox1.Location = new System.Drawing.Point(12, 198);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(815, 88);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opções";
            // 
            // lblExcluir
            // 
            this.lblExcluir.AutoSize = true;
            this.lblExcluir.BackColor = System.Drawing.Color.Transparent;
            this.lblExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblExcluir.Location = new System.Drawing.Point(447, 62);
            this.lblExcluir.Name = "lblExcluir";
            this.lblExcluir.Size = new System.Drawing.Size(92, 18);
            this.lblExcluir.TabIndex = 23;
            this.lblExcluir.Text = "      E&xcluir    ";
            this.lblExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // lblCancelar
            // 
            this.lblCancelar.AutoSize = true;
            this.lblCancelar.BackColor = System.Drawing.Color.Transparent;
            this.lblCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCancelar.Location = new System.Drawing.Point(346, 62);
            this.lblCancelar.Name = "lblCancelar";
            this.lblCancelar.Size = new System.Drawing.Size(91, 18);
            this.lblCancelar.TabIndex = 22;
            this.lblCancelar.Text = "     &Cancelar ";
            this.lblCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // lblSalvar
            // 
            this.lblSalvar.AutoSize = true;
            this.lblSalvar.BackColor = System.Drawing.Color.Transparent;
            this.lblSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSalvar.Location = new System.Drawing.Point(252, 62);
            this.lblSalvar.Name = "lblSalvar";
            this.lblSalvar.Size = new System.Drawing.Size(89, 18);
            this.lblSalvar.TabIndex = 21;
            this.lblSalvar.Text = "      &Salvar    ";
            this.lblSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // lblEditar
            // 
            this.lblEditar.AutoSize = true;
            this.lblEditar.BackColor = System.Drawing.Color.Transparent;
            this.lblEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblEditar.Location = new System.Drawing.Point(169, 62);
            this.lblEditar.Name = "lblEditar";
            this.lblEditar.Size = new System.Drawing.Size(78, 18);
            this.lblEditar.TabIndex = 20;
            this.lblEditar.Text = "    &Editar    ";
            this.lblEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // lblAdicionar
            // 
            this.lblAdicionar.AutoSize = true;
            this.lblAdicionar.BackColor = System.Drawing.Color.Transparent;
            this.lblAdicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAdicionar.Location = new System.Drawing.Point(88, 62);
            this.lblAdicionar.Name = "lblAdicionar";
            this.lblAdicionar.Size = new System.Drawing.Size(69, 18);
            this.lblAdicionar.TabIndex = 19;
            this.lblAdicionar.Text = "&Adicionar";
            this.lblAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.Location = new System.Drawing.Point(469, 13);
            this.btnExcluir.Margin = new System.Windows.Forms.Padding(2);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(56, 51);
            this.btnExcluir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnExcluir.TabIndex = 18;
            this.btnExcluir.TabStop = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.Location = new System.Drawing.Point(371, 13);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(56, 51);
            this.btnCancelar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnCancelar.TabIndex = 17;
            this.btnCancelar.TabStop = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.Location = new System.Drawing.Point(273, 13);
            this.btnSalvar.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(56, 51);
            this.btnSalvar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSalvar.TabIndex = 16;
            this.btnSalvar.TabStop = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Image = ((System.Drawing.Image)(resources.GetObject("btnEditar.Image")));
            this.btnEditar.Location = new System.Drawing.Point(181, 13);
            this.btnEditar.Margin = new System.Windows.Forms.Padding(2);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(56, 51);
            this.btnEditar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnEditar.TabIndex = 15;
            this.btnEditar.TabStop = false;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Image = ((System.Drawing.Image)(resources.GetObject("btnAdicionar.Image")));
            this.btnAdicionar.Location = new System.Drawing.Point(91, 13);
            this.btnAdicionar.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(56, 51);
            this.btnAdicionar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnAdicionar.TabIndex = 14;
            this.btnAdicionar.TabStop = false;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Image = ((System.Drawing.Image)(resources.GetObject("btnBuscar.Image")));
            this.btnBuscar.Location = new System.Drawing.Point(621, 13);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(2);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(56, 51);
            this.btnBuscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnBuscar.TabIndex = 24;
            this.btnBuscar.TabStop = false;
            this.btnBuscar.Visible = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(624, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 18);
            this.label5.TabIndex = 25;
            this.label5.Text = "&Buscar";
            this.label5.Visible = false;
            this.label5.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // btnSemestral
            // 
            this.btnSemestral.Image = ((System.Drawing.Image)(resources.GetObject("btnSemestral.Image")));
            this.btnSemestral.Location = new System.Drawing.Point(755, 13);
            this.btnSemestral.Margin = new System.Windows.Forms.Padding(2);
            this.btnSemestral.Name = "btnSemestral";
            this.btnSemestral.Size = new System.Drawing.Size(56, 51);
            this.btnSemestral.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSemestral.TabIndex = 187;
            this.btnSemestral.TabStop = false;
            this.btnSemestral.Visible = false;
            // 
            // lstNomes
            // 
            this.lstNomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lstNomes.FormattingEnabled = true;
            this.lstNomes.ItemHeight = 18;
            this.lstNomes.Location = new System.Drawing.Point(12, 327);
            this.lstNomes.Name = "lstNomes";
            this.lstNomes.Size = new System.Drawing.Size(814, 166);
            this.lstNomes.TabIndex = 16;
            this.lstNomes.SelectedIndexChanged += new System.EventHandler(this.lstNomes_SelectedIndexChanged);
            // 
            // gbxDados
            // 
            this.gbxDados.Controls.Add(this.txtSemestre);
            this.gbxDados.Controls.Add(this.label4);
            this.gbxDados.Controls.Add(this.label1);
            this.gbxDados.Controls.Add(this.lstCurso);
            this.gbxDados.Controls.Add(this.label3);
            this.gbxDados.Controls.Add(this.label2);
            this.gbxDados.Controls.Add(this.txtAbrev);
            this.gbxDados.Controls.Add(this.txtNome);
            this.gbxDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.gbxDados.ForeColor = System.Drawing.Color.DarkGreen;
            this.gbxDados.Location = new System.Drawing.Point(12, 81);
            this.gbxDados.Name = "gbxDados";
            this.gbxDados.Size = new System.Drawing.Size(815, 112);
            this.gbxDados.TabIndex = 18;
            this.gbxDados.TabStop = false;
            this.gbxDados.Text = "Dados da Materia:";
            // 
            // txtSemestre
            // 
            this.txtSemestre.Location = new System.Drawing.Point(774, 67);
            this.txtSemestre.Name = "txtSemestre";
            this.txtSemestre.Size = new System.Drawing.Size(35, 24);
            this.txtSemestre.TabIndex = 20;
            this.txtSemestre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.validarNumero);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(692, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 18);
            this.label4.TabIndex = 19;
            this.label4.Text = "Semestre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(252, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 18);
            this.label1.TabIndex = 18;
            this.label1.Text = "Curso: ";
            // 
            // lstCurso
            // 
            this.lstCurso.Enabled = false;
            this.lstCurso.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lstCurso.FormattingEnabled = true;
            this.lstCurso.ItemHeight = 18;
            this.lstCurso.Location = new System.Drawing.Point(315, 69);
            this.lstCurso.Name = "lstCurso";
            this.lstCurso.Size = new System.Drawing.Size(371, 22);
            this.lstCurso.TabIndex = 17;
            this.lstCurso.SelectedIndexChanged += new System.EventHandler(this.lstCurso_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(4, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 18);
            this.label3.TabIndex = 16;
            this.label3.Text = "Abreviação:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(24, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 18);
            this.label2.TabIndex = 11;
            this.label2.Text = "Materia:";
            // 
            // txtAbrev
            // 
            this.txtAbrev.Location = new System.Drawing.Point(110, 68);
            this.txtAbrev.Name = "txtAbrev";
            this.txtAbrev.Size = new System.Drawing.Size(120, 24);
            this.txtAbrev.TabIndex = 3;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(110, 28);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(699, 24);
            this.txtNome.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.panel1.Controls.Add(this.lblIFSP);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(838, 79);
            this.panel1.TabIndex = 234;
            // 
            // lblIFSP
            // 
            this.lblIFSP.ActiveBorderThickness = 1;
            this.lblIFSP.ActiveCornerRadius = 20;
            this.lblIFSP.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.ActiveForecolor = System.Drawing.Color.Black;
            this.lblIFSP.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.lblIFSP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lblIFSP.BackgroundImage")));
            this.lblIFSP.ButtonText = "Instituto Federal de São Paulo - Campus Capivari";
            this.lblIFSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIFSP.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIFSP.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleBorderThickness = 1;
            this.lblIFSP.IdleCornerRadius = 20;
            this.lblIFSP.IdleFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleForecolor = System.Drawing.Color.Transparent;
            this.lblIFSP.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.Location = new System.Drawing.Point(150, 19);
            this.lblIFSP.Margin = new System.Windows.Forms.Padding(5);
            this.lblIFSP.Name = "lblIFSP";
            this.lblIFSP.Size = new System.Drawing.Size(539, 41);
            this.lblIFSP.TabIndex = 204;
            this.lblIFSP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIFSP.Click += new System.EventHandler(this.lblIFSP_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // rbtAbrev
            // 
            this.rbtAbrev.AutoSize = true;
            this.rbtAbrev.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtAbrev.Location = new System.Drawing.Point(179, 298);
            this.rbtAbrev.Margin = new System.Windows.Forms.Padding(2);
            this.rbtAbrev.Name = "rbtAbrev";
            this.rbtAbrev.Size = new System.Drawing.Size(159, 24);
            this.rbtAbrev.TabIndex = 244;
            this.rbtAbrev.Text = "Mostar Abreviação";
            this.rbtAbrev.UseVisualStyleBackColor = true;
            this.rbtAbrev.CheckedChanged += new System.EventHandler(this.checkedbusca);
            // 
            // rbtNome
            // 
            this.rbtNome.AutoSize = true;
            this.rbtNome.Checked = true;
            this.rbtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtNome.Location = new System.Drawing.Point(14, 298);
            this.rbtNome.Margin = new System.Windows.Forms.Padding(2);
            this.rbtNome.Name = "rbtNome";
            this.rbtNome.Size = new System.Drawing.Size(122, 24);
            this.rbtNome.TabIndex = 243;
            this.rbtNome.TabStop = true;
            this.rbtNome.Text = "Mostar Nome";
            this.rbtNome.UseVisualStyleBackColor = true;
            this.rbtNome.CheckedChanged += new System.EventHandler(this.checkedbusca);
            // 
            // lblMessagem
            // 
            this.lblMessagem.AutoSize = true;
            this.lblMessagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessagem.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblMessagem.Location = new System.Drawing.Point(389, 295);
            this.lblMessagem.Name = "lblMessagem";
            this.lblMessagem.Size = new System.Drawing.Size(268, 24);
            this.lblMessagem.TabIndex = 245;
            this.lblMessagem.Text = "Registro inserido com sucesso";
            this.lblMessagem.Visible = false;
            // 
            // FrmMateria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(838, 500);
            this.Controls.Add(this.lblMessagem);
            this.Controls.Add(this.rbtAbrev);
            this.Controls.Add(this.rbtNome);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lstNomes);
            this.Controls.Add(this.gbxDados);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FrmMateria";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CadastroMateria";
            this.Load += new System.EventHandler(this.loadFrmCadastroMaterias);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnExcluir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancelar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSalvar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEditar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdicionar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSemestral)).EndInit();
            this.gbxDados.ResumeLayout(false);
            this.gbxDados.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox btnCancelar;
        private System.Windows.Forms.PictureBox btnSalvar;
        private System.Windows.Forms.PictureBox btnEditar;
        private System.Windows.Forms.PictureBox btnAdicionar;
        private System.Windows.Forms.ListBox lstNomes;
        private System.Windows.Forms.GroupBox gbxDados;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAbrev;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.PictureBox btnExcluir;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuThinButton2 lblIFSP;
        private System.Windows.Forms.Label lblExcluir;
        private System.Windows.Forms.Label lblCancelar;
        private System.Windows.Forms.Label lblSalvar;
        private System.Windows.Forms.Label lblEditar;
        private System.Windows.Forms.Label lblAdicionar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstCurso;
        private System.Windows.Forms.RadioButton rbtAbrev;
        private System.Windows.Forms.RadioButton rbtNome;
        private System.Windows.Forms.TextBox txtSemestre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblMessagem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox btnBuscar;
        private System.Windows.Forms.PictureBox btnSemestral;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TIND
{
    public partial class FrmMateria : Form
    {
        public FrmMateria()
        {
            InitializeComponent();
            telainicial();
            this.Text = "Gerenciando Materia";
        }
        
        int operador = 0;
        int idMateria = 0;

        Materia materia = new Materia();

        

        public void telainicial()
        {
            txtNome.MaxLength = 100;
            txtAbrev.MaxLength = 7;
            txtSemestre.MaxLength = 2;            

            txtNome.CharacterCasing = CharacterCasing.Upper;
            txtAbrev.CharacterCasing = CharacterCasing.Upper;

            
            gbxDados.Enabled = false;
            lstNomes.Enabled = true;

            btnAdicionar.Enabled = true;
            btnEditar.Enabled = false;
            btnCancelar.Enabled = false;
            btnSalvar.Enabled = false;
            btnExcluir.Enabled = false;
            rbtNome.Checked = true;
            carregarListBox("Nome");
            
        }

        public void limparTela()
        {
            txtNome.Text = string.Empty;
            txtAbrev.Text = string.Empty;
            txtSemestre.Text = string.Empty;
            btnExcluir.Enabled = false;
            btnEditar.Enabled = false;
            lstCurso.ClearSelected();
        }

        private async void messagem(string messagem)
        {
            lblMessagem.Text = messagem;
            lblMessagem.Visible = true;
            await Task.Delay(1500);
            lblMessagem.Visible = false;
            limparTela();
            telainicial();
        }

        private void falhaNoBanco(string falha, string onde)
        {
            if (MessageBox.Show("Erro Ao Tentar " + onde +" No Banco de Dados\n\nClique Sim Para Ver a \nDescrição Completa do Erro", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Error).ToString().ToUpper() == "YES")
                MessageBox.Show(falha, "Descrição Completa do Erro", MessageBoxButtons.OK);
        }

        public bool verificarCampos()
        {
            bool verificar = true;

            string erros = string.Empty;

            if(string.IsNullOrWhiteSpace(txtNome.Text))
            {                
                erros = "--Preencher Corretamente o Campo NOME da Matéria\n";
                verificar = false;
            }
            
            if(string.IsNullOrWhiteSpace(txtAbrev.Text))
            {             
                erros += "--Preencher Corretamente o Campo Abreviação da Matéria\n";
                verificar = false;
            }

            if(string.IsNullOrEmpty(txtSemestre.Text))
            {
                erros += "--Preencher Corretamente o Campo Semestre da Matéria\n";
                verificar = false;
            }

            if(lstCurso.SelectedItem == null)
            {
                erros += "--Preencher Corretamente o Campo Curso da Matéria\n";
                verificar = false;                
            }

            if(erros != string.Empty)
                if (erros.Length > 56)                
                    MessageBox.Show(erros, "Antenção Corrija Os Seguintes Erros", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show(erros, "Antenção Corrija O Seguinte Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            return verificar;
        }

        public void carregarListBox(string valor)
        {            
            try
            {                      
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_SelMaterias", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;               
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);                
                lstNomes.DisplayMember = valor;
                lstNomes.ValueMember = "Id";
                lstNomes.DataSource = dt;
                conexao.desconectar();                               

                conexao.conectar();
                cmd = new SqlCommand("sp_SelCurso", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                lstCurso.DisplayMember = valor;
                lstCurso.ValueMember = "Id";
                lstCurso.DataSource = dt;
                conexao.desconectar();
            }
            catch (Exception ex)
            {
                falhaNoBanco(ex.ToString(), "Buscar Materia");                      
            }
            lstNomes.ClearSelected();
            lstCurso.ClearSelected();
        }

        public void exibirDadosMateria(int id)
        {
            materia = Materia.getMateria(id);

            if (materia == null)
            {
                limparTela();        
            }
            else
            {
                idMateria = id;
                materia.id = id;
                txtNome.Text = materia.nome;
                txtAbrev.Text = materia.abrev;
                lstCurso.SetSelected(materia.IdCurso - 1, true);
                txtSemestre.Text = materia.semestre.ToString();
                btnExcluir.Enabled = true;
                btnEditar.Enabled = true;                
            }                 
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (verificarCampos())
            {
                materia = new Materia();                
                string resul = string.Empty;
                materia.nome = txtNome.Text;
                materia.abrev = txtAbrev.Text;
                materia.semestre = int.Parse(txtSemestre.Text);
                materia.IdCurso = int.Parse(lstCurso.SelectedValue.ToString());
                materia.id = idMateria;

                if (operador == 1)
                {
                    resul = Materia.setMateria(materia);

                    if (resul == "")                    
                        messagem("Materia Inserida Com Sucesso");
                    else
                        falhaNoBanco(resul, "Inserir Materia");                    
                }
                else 
                {
                    resul = Materia.updMateria(materia);                    

                    if (resul == "")                    
                        messagem("Materia Atualizada Com Sucesso");               
                    else                    
                        falhaNoBanco(resul, "Atualizar Materia");               
                }
                if (rbtNome.Checked == true)
                    carregarListBox("Nome");
                else
                    carregarListBox("Abrev");
            }
        }

        private void lstNomes_SelectedIndexChanged(object sender, EventArgs e)
        {             
            try
            {
                exibirDadosMateria(Convert.ToInt32(lstNomes.SelectedValue));
                btnCancelar.Enabled = true;
            }
            catch
            { }           
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            limparTela();

            gbxDados.Enabled = true;
          

            lstNomes.Enabled = false;
            btnCancelar.Enabled = true;
            btnSalvar.Enabled = true;
            operador = 1;
            txtNome.Focus();
        }
        
        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (lstNomes.SelectedItem != null)
            {               
                gbxDados.Enabled = true;

                lstNomes.Enabled = false;
                btnCancelar.Enabled = true;
                btnSalvar.Enabled = true;
                operador = 0;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            telainicial();
            limparTela();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string result = "";

            if (MessageBox.Show("Esta Materia Será Apagada do Banco de Dados\nVoçê Tem Certeza Que Deseja Prossegui Com a Ação?", "ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question,MessageBoxDefaultButton.Button2).ToString().ToUpper() == "YES")
            {
                result = Materia.delMateria(materia.id);
                
                if (result == "")
                    messagem("Materia Excuilda Com Sucesso");
                else
                    falhaNoBanco(result, "Apagar Materia"); 
            }        
        }

        private void loadFrmCadastroMaterias(object sender, EventArgs e)
        {
            ToolTip toolTip1 = new ToolTip();

            toolTip1.AutoPopDelay = 8000;
            toolTip1.InitialDelay = 100;
            toolTip1.ReshowDelay = 500;

            toolTip1.ShowAlways = true;

            toolTip1.SetToolTip(this.btnAdicionar, "Clique Aqui Para Adicionar Materia");
            toolTip1.SetToolTip(this.btnBuscar,    "Clique Aqui Para Fazer Uma\nBusca Seletiva de Materias");
            toolTip1.SetToolTip(this.btnExcluir,   "Clique Aqui Para Exluir\nA  Materia Selecionada");
            toolTip1.SetToolTip(this.btnEditar,    "Clique Aqui Para Editar\nA Materia Selecionada");
            toolTip1.SetToolTip(this.btnSalvar,    "Clique Aqui Para Salvar \nOs Dados Inseridos");
            toolTip1.SetToolTip(this.btnCancelar,  "Clique Aqui Para Cancelar a Ação Atual");
            toolTip1.SetToolTip(this.rbtAbrev,     "Clique Aqui Para Visualizar\nAs Abreviações das Materias");
            toolTip1.SetToolTip(this.rbtAbrev,     "Clique Aqui Para Visualizar\nO Nome Completo das Materias");
        }    

        private void checkedbusca(object sender, EventArgs e)
        {
            if (rbtNome.Checked == true)
                carregarListBox("Nome");
            else
                carregarListBox("Abrev");          
        }

        private void lstCurso_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                materia.nomeCurso = lstCurso.SelectedValue.ToString();
            }
            catch
            { }
        }

        private void validarNumero(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || e.KeyChar == (char)(Keys.Back))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            /*
            FrmPrincipal frmPrincipal = new FrmPrincipal();

            frmPrincipal.MenuConteudo.Controls.Clear();

            FrmReservaSala myForm = new FrmReservaSala();
            myForm.TopLevel = false;
            myForm.AutoScroll = true;
            this.MenuConteudo.Controls.Add(myForm);
            myForm.Show();*/

            
            FrmBuscaEspecifico frmBusca = new FrmBuscaEspecifico();
            frmBusca.ShowDialog();

        }

        private void lblIFSP_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cpv.ifsp.edu.br/");
        }
    }
}

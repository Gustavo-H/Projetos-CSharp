﻿namespace TIND
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            BunifuAnimatorNS.Animation animation4 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation3 = new BunifuAnimatorNS.Animation();
            this.TopControl = new System.Windows.Forms.Panel();
            this.MenuSidebar = new System.Windows.Forms.PictureBox();
            this.btnDesMaximizar = new System.Windows.Forms.PictureBox();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.btnMaximizar = new System.Windows.Forms.PictureBox();
            this.btnSair = new System.Windows.Forms.PictureBox();
            this.Sidebar = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.btnAulasAgendadas = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTelaVisualizacao = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnReserva = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnMateria = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnProfessor = new Bunifu.Framework.UI.BunifuFlatButton();
            this.LinhaSidebar = new Bunifu.Framework.UI.BunifuSeparator();
            this.SidebarWrapper = new System.Windows.Forms.Panel();
            this.MenuConteudo = new System.Windows.Forms.Panel();
            this.AnimacaoSidebar = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.CurvaSidebar = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.AnimacaoSidebarVolta = new BunifuAnimatorNS.BunifuTransition(this.components);
            label1 = new System.Windows.Forms.Label();
            this.TopControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MenuSidebar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDesMaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSair)).BeginInit();
            this.Sidebar.SuspendLayout();
            this.SidebarWrapper.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            this.AnimacaoSidebar.SetDecoration(label1, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebarVolta.SetDecoration(label1, BunifuAnimatorNS.DecorationType.None);
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.ForeColor = System.Drawing.Color.White;
            label1.Location = new System.Drawing.Point(72, 14);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(113, 20);
            label1.TabIndex = 13;
            label1.Text = "DASHBOARD";
            // 
            // TopControl
            // 
            this.TopControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.TopControl.Controls.Add(this.MenuSidebar);
            this.TopControl.Controls.Add(this.btnDesMaximizar);
            this.TopControl.Controls.Add(this.btnMinimizar);
            this.TopControl.Controls.Add(this.btnMaximizar);
            this.TopControl.Controls.Add(this.btnSair);
            this.TopControl.Controls.Add(label1);
            this.AnimacaoSidebarVolta.SetDecoration(this.TopControl, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.TopControl, BunifuAnimatorNS.DecorationType.None);
            this.TopControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopControl.Location = new System.Drawing.Point(0, 0);
            this.TopControl.Name = "TopControl";
            this.TopControl.Size = new System.Drawing.Size(1103, 75);
            this.TopControl.TabIndex = 197;
            // 
            // MenuSidebar
            // 
            this.AnimacaoSidebar.SetDecoration(this.MenuSidebar, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebarVolta.SetDecoration(this.MenuSidebar, BunifuAnimatorNS.DecorationType.None);
            this.MenuSidebar.Image = ((System.Drawing.Image)(resources.GetObject("MenuSidebar.Image")));
            this.MenuSidebar.Location = new System.Drawing.Point(26, 12);
            this.MenuSidebar.Name = "MenuSidebar";
            this.MenuSidebar.Size = new System.Drawing.Size(30, 30);
            this.MenuSidebar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.MenuSidebar.TabIndex = 20;
            this.MenuSidebar.TabStop = false;
            this.MenuSidebar.Click += new System.EventHandler(this.MenuSidebar_Click);
            // 
            // btnDesMaximizar
            // 
            this.btnDesMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AnimacaoSidebar.SetDecoration(this.btnDesMaximizar, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebarVolta.SetDecoration(this.btnDesMaximizar, BunifuAnimatorNS.DecorationType.None);
            this.btnDesMaximizar.Enabled = false;
            this.btnDesMaximizar.Image = ((System.Drawing.Image)(resources.GetObject("btnDesMaximizar.Image")));
            this.btnDesMaximizar.Location = new System.Drawing.Point(1025, 12);
            this.btnDesMaximizar.Name = "btnDesMaximizar";
            this.btnDesMaximizar.Size = new System.Drawing.Size(30, 30);
            this.btnDesMaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnDesMaximizar.TabIndex = 19;
            this.btnDesMaximizar.TabStop = false;
            this.btnDesMaximizar.Visible = false;
            this.btnDesMaximizar.Click += new System.EventHandler(this.BtnMaximizar_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AnimacaoSidebar.SetDecoration(this.btnMinimizar, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebarVolta.SetDecoration(this.btnMinimizar, BunifuAnimatorNS.DecorationType.None);
            this.btnMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimizar.Image")));
            this.btnMinimizar.Location = new System.Drawing.Point(989, 12);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(30, 30);
            this.btnMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMinimizar.TabIndex = 18;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.BtnMinimizar_Click);
            // 
            // btnMaximizar
            // 
            this.btnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AnimacaoSidebar.SetDecoration(this.btnMaximizar, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebarVolta.SetDecoration(this.btnMaximizar, BunifuAnimatorNS.DecorationType.None);
            this.btnMaximizar.Enabled = false;
            this.btnMaximizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMaximizar.Image")));
            this.btnMaximizar.Location = new System.Drawing.Point(1025, 12);
            this.btnMaximizar.Name = "btnMaximizar";
            this.btnMaximizar.Size = new System.Drawing.Size(30, 30);
            this.btnMaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMaximizar.TabIndex = 17;
            this.btnMaximizar.TabStop = false;
            this.btnMaximizar.Click += new System.EventHandler(this.BtnMaximizar_Click_1);
            // 
            // btnSair
            // 
            this.btnSair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AnimacaoSidebar.SetDecoration(this.btnSair, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebarVolta.SetDecoration(this.btnSair, BunifuAnimatorNS.DecorationType.None);
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.Location = new System.Drawing.Point(1061, 12);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(30, 30);
            this.btnSair.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSair.TabIndex = 16;
            this.btnSair.TabStop = false;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Sidebar
            // 
            this.Sidebar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.Sidebar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Sidebar.BackgroundImage")));
            this.Sidebar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Sidebar.Controls.Add(this.btnAulasAgendadas);
            this.Sidebar.Controls.Add(this.btnTelaVisualizacao);
            this.Sidebar.Controls.Add(this.btnReserva);
            this.Sidebar.Controls.Add(this.btnMateria);
            this.Sidebar.Controls.Add(this.btnProfessor);
            this.Sidebar.Controls.Add(this.LinhaSidebar);
            this.AnimacaoSidebarVolta.SetDecoration(this.Sidebar, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.Sidebar, BunifuAnimatorNS.DecorationType.None);
            this.Sidebar.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(165)))), ((int)(((byte)(80)))));
            this.Sidebar.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(165)))), ((int)(((byte)(80)))));
            this.Sidebar.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(165)))), ((int)(((byte)(80)))));
            this.Sidebar.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.Sidebar.Location = new System.Drawing.Point(12, 6);
            this.Sidebar.Name = "Sidebar";
            this.Sidebar.Quality = 10;
            this.Sidebar.Size = new System.Drawing.Size(241, 540);
            this.Sidebar.TabIndex = 0;
            // 
            // btnAulasAgendadas
            // 
            this.btnAulasAgendadas.Activecolor = System.Drawing.Color.Transparent;
            this.btnAulasAgendadas.BackColor = System.Drawing.Color.Transparent;
            this.btnAulasAgendadas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAulasAgendadas.BorderRadius = 0;
            this.btnAulasAgendadas.ButtonText = "     Aulas Agendadas";
            this.btnAulasAgendadas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AnimacaoSidebarVolta.SetDecoration(this.btnAulasAgendadas, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.btnAulasAgendadas, BunifuAnimatorNS.DecorationType.None);
            this.btnAulasAgendadas.DisabledColor = System.Drawing.Color.Gray;
            this.btnAulasAgendadas.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAulasAgendadas.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAulasAgendadas.Iconimage")));
            this.btnAulasAgendadas.Iconimage_right = null;
            this.btnAulasAgendadas.Iconimage_right_Selected = null;
            this.btnAulasAgendadas.Iconimage_Selected = null;
            this.btnAulasAgendadas.IconMarginLeft = 0;
            this.btnAulasAgendadas.IconMarginRight = 0;
            this.btnAulasAgendadas.IconRightVisible = true;
            this.btnAulasAgendadas.IconRightZoom = 0D;
            this.btnAulasAgendadas.IconVisible = true;
            this.btnAulasAgendadas.IconZoom = 60D;
            this.btnAulasAgendadas.IsTab = false;
            this.btnAulasAgendadas.Location = new System.Drawing.Point(14, 264);
            this.btnAulasAgendadas.Name = "btnAulasAgendadas";
            this.btnAulasAgendadas.Normalcolor = System.Drawing.Color.Transparent;
            this.btnAulasAgendadas.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnAulasAgendadas.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAulasAgendadas.selected = false;
            this.btnAulasAgendadas.Size = new System.Drawing.Size(233, 48);
            this.btnAulasAgendadas.TabIndex = 27;
            this.btnAulasAgendadas.Text = "     Aulas Agendadas";
            this.btnAulasAgendadas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAulasAgendadas.Textcolor = System.Drawing.Color.White;
            this.btnAulasAgendadas.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAulasAgendadas.Click += new System.EventHandler(this.btnAulasAgendadas_Click);
            // 
            // btnTelaVisualizacao
            // 
            this.btnTelaVisualizacao.Activecolor = System.Drawing.Color.Transparent;
            this.btnTelaVisualizacao.BackColor = System.Drawing.Color.Transparent;
            this.btnTelaVisualizacao.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTelaVisualizacao.BorderRadius = 0;
            this.btnTelaVisualizacao.ButtonText = "     Tela de Visualização";
            this.btnTelaVisualizacao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AnimacaoSidebarVolta.SetDecoration(this.btnTelaVisualizacao, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.btnTelaVisualizacao, BunifuAnimatorNS.DecorationType.None);
            this.btnTelaVisualizacao.DisabledColor = System.Drawing.Color.Gray;
            this.btnTelaVisualizacao.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTelaVisualizacao.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnTelaVisualizacao.Iconimage")));
            this.btnTelaVisualizacao.Iconimage_right = null;
            this.btnTelaVisualizacao.Iconimage_right_Selected = null;
            this.btnTelaVisualizacao.Iconimage_Selected = null;
            this.btnTelaVisualizacao.IconMarginLeft = 0;
            this.btnTelaVisualizacao.IconMarginRight = 0;
            this.btnTelaVisualizacao.IconRightVisible = true;
            this.btnTelaVisualizacao.IconRightZoom = 0D;
            this.btnTelaVisualizacao.IconVisible = true;
            this.btnTelaVisualizacao.IconZoom = 60D;
            this.btnTelaVisualizacao.IsTab = false;
            this.btnTelaVisualizacao.Location = new System.Drawing.Point(14, 12);
            this.btnTelaVisualizacao.Name = "btnTelaVisualizacao";
            this.btnTelaVisualizacao.Normalcolor = System.Drawing.Color.Transparent;
            this.btnTelaVisualizacao.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnTelaVisualizacao.OnHoverTextColor = System.Drawing.Color.White;
            this.btnTelaVisualizacao.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnTelaVisualizacao.selected = false;
            this.btnTelaVisualizacao.Size = new System.Drawing.Size(233, 48);
            this.btnTelaVisualizacao.TabIndex = 26;
            this.btnTelaVisualizacao.Text = "     Tela de Visualização";
            this.btnTelaVisualizacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTelaVisualizacao.Textcolor = System.Drawing.Color.White;
            this.btnTelaVisualizacao.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTelaVisualizacao.Click += new System.EventHandler(this.BtnTitulo_Click);
            // 
            // btnReserva
            // 
            this.btnReserva.Activecolor = System.Drawing.Color.Transparent;
            this.btnReserva.BackColor = System.Drawing.Color.Transparent;
            this.btnReserva.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReserva.BorderRadius = 0;
            this.btnReserva.ButtonText = "     Fazer Reserva de Salas";
            this.btnReserva.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AnimacaoSidebarVolta.SetDecoration(this.btnReserva, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.btnReserva, BunifuAnimatorNS.DecorationType.None);
            this.btnReserva.DisabledColor = System.Drawing.Color.Gray;
            this.btnReserva.Iconcolor = System.Drawing.Color.Transparent;
            this.btnReserva.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnReserva.Iconimage")));
            this.btnReserva.Iconimage_right = null;
            this.btnReserva.Iconimage_right_Selected = null;
            this.btnReserva.Iconimage_Selected = null;
            this.btnReserva.IconMarginLeft = 0;
            this.btnReserva.IconMarginRight = 0;
            this.btnReserva.IconRightVisible = true;
            this.btnReserva.IconRightZoom = 0D;
            this.btnReserva.IconVisible = true;
            this.btnReserva.IconZoom = 60D;
            this.btnReserva.IsTab = false;
            this.btnReserva.Location = new System.Drawing.Point(14, 204);
            this.btnReserva.Name = "btnReserva";
            this.btnReserva.Normalcolor = System.Drawing.Color.Transparent;
            this.btnReserva.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnReserva.OnHoverTextColor = System.Drawing.Color.White;
            this.btnReserva.selected = false;
            this.btnReserva.Size = new System.Drawing.Size(233, 48);
            this.btnReserva.TabIndex = 25;
            this.btnReserva.Text = "     Fazer Reserva de Salas";
            this.btnReserva.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReserva.Textcolor = System.Drawing.Color.White;
            this.btnReserva.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReserva.Click += new System.EventHandler(this.BtnReserva_Click);
            // 
            // btnMateria
            // 
            this.btnMateria.Activecolor = System.Drawing.Color.Transparent;
            this.btnMateria.BackColor = System.Drawing.Color.Transparent;
            this.btnMateria.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMateria.BorderRadius = 0;
            this.btnMateria.ButtonText = "   Gerenciar Matérias";
            this.btnMateria.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AnimacaoSidebarVolta.SetDecoration(this.btnMateria, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.btnMateria, BunifuAnimatorNS.DecorationType.None);
            this.btnMateria.DisabledColor = System.Drawing.Color.Gray;
            this.btnMateria.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMateria.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnMateria.Iconimage")));
            this.btnMateria.Iconimage_right = null;
            this.btnMateria.Iconimage_right_Selected = null;
            this.btnMateria.Iconimage_Selected = null;
            this.btnMateria.IconMarginLeft = 0;
            this.btnMateria.IconMarginRight = 0;
            this.btnMateria.IconRightVisible = true;
            this.btnMateria.IconRightZoom = 0D;
            this.btnMateria.IconVisible = true;
            this.btnMateria.IconZoom = 70D;
            this.btnMateria.IsTab = false;
            this.btnMateria.Location = new System.Drawing.Point(14, 143);
            this.btnMateria.Name = "btnMateria";
            this.btnMateria.Normalcolor = System.Drawing.Color.Transparent;
            this.btnMateria.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnMateria.OnHoverTextColor = System.Drawing.Color.White;
            this.btnMateria.selected = false;
            this.btnMateria.Size = new System.Drawing.Size(239, 55);
            this.btnMateria.TabIndex = 24;
            this.btnMateria.Text = "   Gerenciar Matérias";
            this.btnMateria.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMateria.Textcolor = System.Drawing.Color.White;
            this.btnMateria.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMateria.Click += new System.EventHandler(this.BtnMateria_Click);
            // 
            // btnProfessor
            // 
            this.btnProfessor.Activecolor = System.Drawing.Color.Transparent;
            this.btnProfessor.BackColor = System.Drawing.Color.Transparent;
            this.btnProfessor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProfessor.BorderRadius = 0;
            this.btnProfessor.ButtonText = "     Gerenciar Professores";
            this.btnProfessor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AnimacaoSidebarVolta.SetDecoration(this.btnProfessor, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.btnProfessor, BunifuAnimatorNS.DecorationType.None);
            this.btnProfessor.DisabledColor = System.Drawing.Color.Gray;
            this.btnProfessor.Iconcolor = System.Drawing.Color.Transparent;
            this.btnProfessor.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnProfessor.Iconimage")));
            this.btnProfessor.Iconimage_right = null;
            this.btnProfessor.Iconimage_right_Selected = null;
            this.btnProfessor.Iconimage_Selected = null;
            this.btnProfessor.IconMarginLeft = 0;
            this.btnProfessor.IconMarginRight = 0;
            this.btnProfessor.IconRightVisible = true;
            this.btnProfessor.IconRightZoom = 0D;
            this.btnProfessor.IconVisible = true;
            this.btnProfessor.IconZoom = 60D;
            this.btnProfessor.IsTab = false;
            this.btnProfessor.Location = new System.Drawing.Point(14, 89);
            this.btnProfessor.Name = "btnProfessor";
            this.btnProfessor.Normalcolor = System.Drawing.Color.Transparent;
            this.btnProfessor.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnProfessor.OnHoverTextColor = System.Drawing.Color.White;
            this.btnProfessor.selected = false;
            this.btnProfessor.Size = new System.Drawing.Size(233, 48);
            this.btnProfessor.TabIndex = 2;
            this.btnProfessor.Text = "     Gerenciar Professores";
            this.btnProfessor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProfessor.Textcolor = System.Drawing.Color.White;
            this.btnProfessor.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfessor.Click += new System.EventHandler(this.BtnProfessor_Click);
            // 
            // LinhaSidebar
            // 
            this.LinhaSidebar.BackColor = System.Drawing.Color.Transparent;
            this.AnimacaoSidebarVolta.SetDecoration(this.LinhaSidebar, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.LinhaSidebar, BunifuAnimatorNS.DecorationType.None);
            this.LinhaSidebar.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LinhaSidebar.LineThickness = 1;
            this.LinhaSidebar.Location = new System.Drawing.Point(14, 66);
            this.LinhaSidebar.Name = "LinhaSidebar";
            this.LinhaSidebar.Size = new System.Drawing.Size(210, 12);
            this.LinhaSidebar.TabIndex = 23;
            this.LinhaSidebar.Transparency = 255;
            this.LinhaSidebar.Vertical = false;
            // 
            // SidebarWrapper
            // 
            this.SidebarWrapper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.SidebarWrapper.Controls.Add(this.Sidebar);
            this.AnimacaoSidebarVolta.SetDecoration(this.SidebarWrapper, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.SidebarWrapper, BunifuAnimatorNS.DecorationType.None);
            this.SidebarWrapper.Dock = System.Windows.Forms.DockStyle.Left;
            this.SidebarWrapper.Location = new System.Drawing.Point(0, 75);
            this.SidebarWrapper.Name = "SidebarWrapper";
            this.SidebarWrapper.Size = new System.Drawing.Size(253, 546);
            this.SidebarWrapper.TabIndex = 196;
            // 
            // MenuConteudo
            // 
            this.MenuConteudo.AutoScroll = true;
            this.MenuConteudo.AutoSize = true;
            this.MenuConteudo.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MenuConteudo.BackColor = System.Drawing.Color.White;
            this.AnimacaoSidebarVolta.SetDecoration(this.MenuConteudo, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebar.SetDecoration(this.MenuConteudo, BunifuAnimatorNS.DecorationType.None);
            this.MenuConteudo.Location = new System.Drawing.Point(271, 75);
            this.MenuConteudo.Name = "MenuConteudo";
            this.MenuConteudo.Size = new System.Drawing.Size(0, 0);
            this.MenuConteudo.TabIndex = 198;
            // 
            // AnimacaoSidebar
            // 
            this.AnimacaoSidebar.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.AnimacaoSidebar.Cursor = null;
            animation4.AnimateOnlyDifferences = true;
            animation4.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.BlindCoeff")));
            animation4.LeafCoeff = 0F;
            animation4.MaxTime = 1F;
            animation4.MinTime = 0F;
            animation4.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.MosaicCoeff")));
            animation4.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation4.MosaicShift")));
            animation4.MosaicSize = 0;
            animation4.Padding = new System.Windows.Forms.Padding(0);
            animation4.RotateCoeff = 0F;
            animation4.RotateLimit = 0F;
            animation4.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.ScaleCoeff")));
            animation4.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.SlideCoeff")));
            animation4.TimeCoeff = 0F;
            animation4.TransparencyCoeff = 1F;
            this.AnimacaoSidebar.DefaultAnimation = animation4;
            // 
            // CurvaSidebar
            // 
            this.CurvaSidebar.ElipseRadius = 7;
            this.CurvaSidebar.TargetControl = this.Sidebar;
            // 
            // AnimacaoSidebarVolta
            // 
            this.AnimacaoSidebarVolta.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.AnimacaoSidebarVolta.Cursor = null;
            animation3.AnimateOnlyDifferences = true;
            animation3.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.BlindCoeff")));
            animation3.LeafCoeff = 0F;
            animation3.MaxTime = 1F;
            animation3.MinTime = 0F;
            animation3.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicCoeff")));
            animation3.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicShift")));
            animation3.MosaicSize = 0;
            animation3.Padding = new System.Windows.Forms.Padding(0);
            animation3.RotateCoeff = 0F;
            animation3.RotateLimit = 0F;
            animation3.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.ScaleCoeff")));
            animation3.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.SlideCoeff")));
            animation3.TimeCoeff = 0F;
            animation3.TransparencyCoeff = 1F;
            this.AnimacaoSidebarVolta.DefaultAnimation = animation3;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(1103, 621);
            this.Controls.Add(this.SidebarWrapper);
            this.Controls.Add(this.MenuConteudo);
            this.Controls.Add(this.TopControl);
            this.AnimacaoSidebar.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.AnimacaoSidebarVolta.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.TopControl.ResumeLayout(false);
            this.TopControl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MenuSidebar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDesMaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSair)).EndInit();
            this.Sidebar.ResumeLayout(false);
            this.SidebarWrapper.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel TopControl;
        private System.Windows.Forms.PictureBox MenuSidebar;
        private BunifuAnimatorNS.BunifuTransition AnimacaoSidebar;
        private BunifuAnimatorNS.BunifuTransition AnimacaoSidebarVolta;
        private System.Windows.Forms.PictureBox btnDesMaximizar;
        private System.Windows.Forms.PictureBox btnMinimizar;
        private System.Windows.Forms.PictureBox btnMaximizar;
        private System.Windows.Forms.PictureBox btnSair;
        private Bunifu.Framework.UI.BunifuGradientPanel Sidebar;
        private Bunifu.Framework.UI.BunifuFlatButton btnReserva;
        private Bunifu.Framework.UI.BunifuFlatButton btnMateria;
        private Bunifu.Framework.UI.BunifuFlatButton btnProfessor;
        private Bunifu.Framework.UI.BunifuSeparator LinhaSidebar;
        private System.Windows.Forms.Panel SidebarWrapper;
        private System.Windows.Forms.Panel MenuConteudo;
        private Bunifu.Framework.UI.BunifuElipse CurvaSidebar;
        private Bunifu.Framework.UI.BunifuFlatButton btnTelaVisualizacao;
        private Bunifu.Framework.UI.BunifuFlatButton btnAulasAgendadas;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Timers;

namespace TIND
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
            this.Text = "FGH_Viewer";
        }        

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
            FrmPrincipal frm = new FrmPrincipal();
            frm.ShowDialog();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnMaximizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Normal;
            btnMaximizar.Visible = true;
            btnDesMaximizar.Visible = false;
        }

        private void BtnMinimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void BtnMaximizar_Click_1(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Maximized;
            btnMaximizar.Visible = false;
            btnDesMaximizar.Visible = true;
        }

        private void MenuSidebar_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 268)
            {
                Sidebar.Visible = false;
                Sidebar.Width = 68;
                SidebarWrapper.Width = 90;
                MenuConteudo.Width = 1104;
                MenuConteudo.Anchor = AnchorStyles.Left;
                LinhaSidebar.Width = 25;
                AnimacaoSidebar.Show(Sidebar);
            }
            else
            {
                Sidebar.Visible = false;
                Sidebar.Width = 268;
                SidebarWrapper.Width = 241;
                MenuConteudo.Width = 1104;
                LinhaSidebar.Width = 252;
                AnimacaoSidebarVolta.Show(Sidebar);
            }
        }



        private void BtnMateria_Click(object sender, EventArgs e)
        {
            this.MenuConteudo.Controls.Clear();
            FrmMateria myForm = new FrmMateria();
            myForm.TopLevel = false;
            myForm.AutoScroll = true;
            this.MenuConteudo.Controls.Add(myForm);
            myForm.Show();
        }

        private void BtnReserva_Click(object sender, EventArgs e)
        {
            this.MenuConteudo.Controls.Clear();

            FrmReservaSala myForm = new FrmReservaSala();
            myForm.TopLevel = false;
            myForm.AutoScroll = true;
            this.MenuConteudo.Controls.Add(myForm);
            myForm.Show();
        }

        private void BtnProfessor_Click(object sender, EventArgs e)
        {
            this.MenuConteudo.Controls.Clear();

            FrmProfessor myForm = new FrmProfessor();
            myForm.TopLevel = false;
            myForm.AutoScroll = true;            
            this.MenuConteudo.Controls.Add(myForm);
            myForm.Show();
        }

        private void BtnTitulo_Click(object sender, EventArgs e)
        {
            //this.MenuConteudo.Controls.Clear();
            
            FrmVizualizarSala myForm = new FrmVizualizarSala();
            //myForm.TopLevel = false;
            //myForm.AutoScroll = true;
            //myForm.AutoSize = true;
            //this.MenuConteudo.Controls.Add(myForm);
            this.Hide();
            myForm.ShowDialog();
            this.Show();
        }

        private void btnAulasAgendadas_Click(object sender, EventArgs e)
        {
            this.MenuConteudo.Controls.Clear();

            FrmSalasReservadas myForm = new FrmSalasReservadas();
            myForm.TopLevel = false;
            myForm.AutoScroll = true;
            this.MenuConteudo.Controls.Add(myForm);
            myForm.Show();
        }
        public static void carrregarForm(Form meuForm)
        {
            //this.MenuConteudo.Controls.Clear();
            FrmMateria myForm = new FrmMateria();
            myForm.TopLevel = false;
            myForm.AutoScroll = true;
           // this.MenuConteudo.Controls.Add(myForm);
            myForm.Show();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }

    }
}

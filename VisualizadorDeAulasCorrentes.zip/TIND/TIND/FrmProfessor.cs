﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TIND
{
    public partial class FrmProfessor : Form
    {
        public FrmProfessor()
        {
            InitializeComponent();
            telainicial();
            this.Text = "Gerenciando Professor";
        }
        
        int operador = 0;        

        Professor professor = new Professor();

        public bool verificarCampos()
        {
            bool verificar = true;

            string erros = string.Empty;

            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                erros = "--Preencher Corretamente o Campo NOME do Professor\n";
                verificar = false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                erros += "--Preencher Corretamente o Campo E-Mail do Professor\n";
                verificar = false;
            }

            if (string.IsNullOrEmpty(txtProntuario.Text))
            {
                erros += "--Preencher Corretamente o Campo Prontuario do Professor\n";
                verificar = false;
            }           

            if (erros != string.Empty)
                if (erros.Length > 56)
                    MessageBox.Show(erros, "Antenção Corrija Os Seguintes Erros", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show(erros, "Antenção Corrija O Seguinte Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            return verificar;            
        }

        public void telainicial()
        {
            txtNome.MaxLength = 100;
            txtProntuario.MaxLength = 7;
            txtEmail.MaxLength = 100;

            txtNome.CharacterCasing = CharacterCasing.Upper;
            txtProntuario.CharacterCasing = CharacterCasing.Upper;
            txtEmail.CharacterCasing = CharacterCasing.Upper;

            lstNomes.Enabled = true;
            txtEmail.Enabled = false;
            txtNome.Enabled = false;
            txtProntuario.Enabled = false;
            btnAdicionar.Enabled = true;
            btnEditar.Enabled = false;
            btnCancelar.Enabled = false;
            btnSalvar.Enabled = false;
            carregarListBox();

        }

        public void limparTela()
        {
            txtNome.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtProntuario.Text = string.Empty;
        }

        private async void messagem(string messagem)
        {
            lblMessagem.Text = messagem;
            lblMessagem.Visible = true;
            await Task.Delay(1500);
            lblMessagem.Visible = false;
            limparTela();
            telainicial();
        }

        private void falhaNoBanco(string falha, string onde)
        {
            if (MessageBox.Show("Erro Ao Tentar " + onde + " No Banco de Dados\n\nClique Sim Para Ver a \nDescrição Completa do Erro", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Error).ToString().ToUpper() == "YES")
                MessageBox.Show(falha, "Descrição Completa do Erro", MessageBoxButtons.OK);
        }

        public void carregarListBox()
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_SelProfessores", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                lstNomes.DisplayMember = "Nome";
                lstNomes.ValueMember = "Id";
                lstNomes.DataSource = dt;
                conexao.desconectar();            
            }
            catch (Exception ex)
            {
                falhaNoBanco(ex.ToString(), "Buscar Professor");
            }
            lstNomes.ClearSelected();
        }

        public void exibirDadosProfessor(int id)
        {
            professor = Professor.getProfessor(id);

            if (professor == null)
            {
                limparTela();
            }
            else
            {
                professor.id = id;
                txtNome.Text = professor.nome;
                txtEmail.Text = professor.email;
                txtProntuario.Text = professor.ra;
                btnExcluir.Enabled = true;
                btnEditar.Enabled = true;
            }
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            limparTela();
            txtEmail.Enabled = true;
            txtNome.Enabled = true;
            txtProntuario.Enabled = true;

            lstNomes.Enabled = false;
            btnCancelar.Enabled = true;
            btnSalvar.Enabled = true;
            operador = 1;
            txtNome.Focus();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (verificarCampos())
            {
                string resul = string.Empty;
                professor.nome = txtNome.Text;
                professor.email = txtEmail.Text;
                professor.ra = txtProntuario.Text;

                if (operador == 1)
                {
                    resul = Professor.setProfessor(professor);

                    if (resul == "")
                        messagem("Professor Inserido Com Sucesso");
                    else
                        falhaNoBanco(resul, "Inserir Professor");
                }
                else
                {
                    resul = Professor.updProfessor(professor);

                    if (resul == "")
                        messagem("Professor Atualizado Com Sucesso");
                    else
                        falhaNoBanco(resul, "Atualizar Professor");
                }
                carregarListBox();
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            txtEmail.Enabled = true;
            txtNome.Enabled = true;
            txtProntuario.Enabled = true;

            lstNomes.Enabled = false;
            btnCancelar.Enabled = true;
            btnSalvar.Enabled = true;
            operador = 0;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            telainicial();
            limparTela();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstNomes_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                exibirDadosProfessor(Convert.ToInt32(lstNomes.SelectedValue.ToString()));
                btnCancelar.Enabled = true;
                btnEditar.Enabled = true;
            }
            catch
            { }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
            FrmPrincipal frm = new FrmPrincipal();
            frm.ShowDialog();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string result = "";

            if (MessageBox.Show("Este Professor Será Apagado do Banco de Dados\nVoçê Tem Certeza Que Deseja Prossegui Com a Ação?", "ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2).ToString().ToUpper() == "YES")
            {
                result = Professor.delProfessor(professor.id);

                if (result == "")
                    messagem("Professor Excuildo Com Sucesso");
                else
                    falhaNoBanco(result, "Apagar Professor");               
            } 
        }

        private void FrmProfessor_Load(object sender, EventArgs e)
        {
            ToolTip toolTip1 = new ToolTip();

            toolTip1.AutoPopDelay = 8000;
            toolTip1.InitialDelay = 100;
            toolTip1.ReshowDelay = 500;

            toolTip1.ShowAlways = true;

            toolTip1.SetToolTip(this.btnAdicionar, "Clique Aqui Para Adicionar Professor");
            toolTip1.SetToolTip(this.btnExcluir,   "Clique Aqui Para Exluir\nO Professor Selecionado");
            toolTip1.SetToolTip(this.btnEditar,    "Clique Aqui Para Editar\nO Professor Selecionado");
            toolTip1.SetToolTip(this.btnSalvar,    "Clique Aqui Para Salvar \nOs Dados Inseridos");
            toolTip1.SetToolTip(this.btnCancelar,  "Clique Aqui Para Cancelar a Ação Atual");            
        }

        private void lblIFSP_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cpv.ifsp.edu.br/");
        }
    }

}

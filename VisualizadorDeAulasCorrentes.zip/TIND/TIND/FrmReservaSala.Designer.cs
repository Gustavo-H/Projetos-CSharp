﻿namespace TIND
{
    partial class FrmReservaSala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmReservaSala));
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.PictureBox();
            this.btnRight = new System.Windows.Forms.PictureBox();
            this.btnLeft = new System.Windows.Forms.PictureBox();
            this.gbxDados = new System.Windows.Forms.GroupBox();
            this.rbtAbrev = new System.Windows.Forms.RadioButton();
            this.rbtNome = new System.Windows.Forms.RadioButton();
            this.lblMessagem = new System.Windows.Forms.Label();
            this.panelSala = new System.Windows.Forms.Panel();
            this.lstProfessor = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lstSalas = new System.Windows.Forms.ListBox();
            this.panelMateria = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.dtpDia = new System.Windows.Forms.DateTimePicker();
            this.dtpFim = new System.Windows.Forms.DateTimePicker();
            this.dtpInicio = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lstMaterias = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panelCurso = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.lstSemestre = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lstCurso = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblIFSP = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gbxOpcoes = new System.Windows.Forms.GroupBox();
            this.lblSalvar = new System.Windows.Forms.Label();
            this.btnSalvar = new System.Windows.Forms.PictureBox();
            this.lblCancelar = new System.Windows.Forms.Label();
            this.lblEditar = new System.Windows.Forms.Label();
            this.lblAdicionar = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancelar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLeft)).BeginInit();
            this.gbxDados.SuspendLayout();
            this.panelSala.SuspendLayout();
            this.panelMateria.SuspendLayout();
            this.panelCurso.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.gbxOpcoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSalvar)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(356, 175);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 13);
            this.label10.TabIndex = 179;
            this.label10.Text = "C";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(356, 232);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 178;
            this.label8.Text = "B";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(356, 292);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 177;
            this.label7.Text = "A";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.Location = new System.Drawing.Point(9, 348);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(56, 51);
            this.btnCancelar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnCancelar.TabIndex = 17;
            this.btnCancelar.TabStop = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnRight
            // 
            this.btnRight.Image = ((System.Drawing.Image)(resources.GetObject("btnRight.Image")));
            this.btnRight.Location = new System.Drawing.Point(10, 141);
            this.btnRight.Margin = new System.Windows.Forms.Padding(2);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(56, 51);
            this.btnRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnRight.TabIndex = 15;
            this.btnRight.TabStop = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.ErrorImage = ((System.Drawing.Image)(resources.GetObject("btnLeft.ErrorImage")));
            this.btnLeft.Image = ((System.Drawing.Image)(resources.GetObject("btnLeft.Image")));
            this.btnLeft.Location = new System.Drawing.Point(10, 31);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(2);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(56, 51);
            this.btnLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnLeft.TabIndex = 14;
            this.btnLeft.TabStop = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // gbxDados
            // 
            this.gbxDados.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxDados.Controls.Add(this.rbtAbrev);
            this.gbxDados.Controls.Add(this.rbtNome);
            this.gbxDados.Controls.Add(this.lblMessagem);
            this.gbxDados.Controls.Add(this.panelSala);
            this.gbxDados.Controls.Add(this.panelMateria);
            this.gbxDados.Controls.Add(this.panelCurso);
            this.gbxDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.gbxDados.ForeColor = System.Drawing.Color.DarkGreen;
            this.gbxDados.Location = new System.Drawing.Point(2, 86);
            this.gbxDados.Name = "gbxDados";
            this.gbxDados.Size = new System.Drawing.Size(752, 393);
            this.gbxDados.TabIndex = 182;
            this.gbxDados.TabStop = false;
            this.gbxDados.Text = "Dados da Reserva:";
            // 
            // rbtAbrev
            // 
            this.rbtAbrev.AutoSize = true;
            this.rbtAbrev.Checked = true;
            this.rbtAbrev.Location = new System.Drawing.Point(72, 22);
            this.rbtAbrev.Name = "rbtAbrev";
            this.rbtAbrev.Size = new System.Drawing.Size(99, 22);
            this.rbtAbrev.TabIndex = 259;
            this.rbtAbrev.TabStop = true;
            this.rbtAbrev.Text = "Abreviação";
            this.rbtAbrev.UseVisualStyleBackColor = true;
            this.rbtAbrev.CheckedChanged += new System.EventHandler(this.checkedRbts);
            // 
            // rbtNome
            // 
            this.rbtNome.AutoSize = true;
            this.rbtNome.Location = new System.Drawing.Point(209, 22);
            this.rbtNome.Name = "rbtNome";
            this.rbtNome.Size = new System.Drawing.Size(67, 22);
            this.rbtNome.TabIndex = 258;
            this.rbtNome.Text = "Nome";
            this.rbtNome.UseVisualStyleBackColor = true;
            this.rbtNome.CheckedChanged += new System.EventHandler(this.checkedRbts);
            // 
            // lblMessagem
            // 
            this.lblMessagem.AutoSize = true;
            this.lblMessagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessagem.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblMessagem.Location = new System.Drawing.Point(297, 20);
            this.lblMessagem.Name = "lblMessagem";
            this.lblMessagem.Size = new System.Drawing.Size(268, 24);
            this.lblMessagem.TabIndex = 257;
            this.lblMessagem.Text = "Registro inserido com sucesso";
            this.lblMessagem.Visible = false;
            // 
            // panelSala
            // 
            this.panelSala.Controls.Add(this.lstProfessor);
            this.panelSala.Controls.Add(this.label1);
            this.panelSala.Controls.Add(this.label3);
            this.panelSala.Controls.Add(this.lstSalas);
            this.panelSala.Location = new System.Drawing.Point(7, 274);
            this.panelSala.Name = "panelSala";
            this.panelSala.Size = new System.Drawing.Size(745, 119);
            this.panelSala.TabIndex = 256;
            // 
            // lstProfessor
            // 
            this.lstProfessor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lstProfessor.FormattingEnabled = true;
            this.lstProfessor.ItemHeight = 18;
            this.lstProfessor.Location = new System.Drawing.Point(521, 7);
            this.lstProfessor.Name = "lstProfessor";
            this.lstProfessor.Size = new System.Drawing.Size(218, 94);
            this.lstProfessor.TabIndex = 257;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(438, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 256;
            this.label1.Text = "Professor:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(4, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 18);
            this.label3.TabIndex = 254;
            this.label3.Text = "Salas:";
            // 
            // lstSalas
            // 
            this.lstSalas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lstSalas.FormattingEnabled = true;
            this.lstSalas.ItemHeight = 18;
            this.lstSalas.Location = new System.Drawing.Point(65, 7);
            this.lstSalas.Name = "lstSalas";
            this.lstSalas.Size = new System.Drawing.Size(205, 94);
            this.lstSalas.TabIndex = 255;
            // 
            // panelMateria
            // 
            this.panelMateria.Controls.Add(this.label11);
            this.panelMateria.Controls.Add(this.dtpDia);
            this.panelMateria.Controls.Add(this.dtpFim);
            this.panelMateria.Controls.Add(this.dtpInicio);
            this.panelMateria.Controls.Add(this.label5);
            this.panelMateria.Controls.Add(this.label4);
            this.panelMateria.Controls.Add(this.lstMaterias);
            this.panelMateria.Controls.Add(this.label2);
            this.panelMateria.Location = new System.Drawing.Point(7, 166);
            this.panelMateria.Name = "panelMateria";
            this.panelMateria.Size = new System.Drawing.Size(745, 107);
            this.panelMateria.TabIndex = 255;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkGreen;
            this.label11.Location = new System.Drawing.Point(496, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 18);
            this.label11.TabIndex = 259;
            this.label11.Text = "Dia da Aula:";
            // 
            // dtpDia
            // 
            this.dtpDia.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDia.Location = new System.Drawing.Point(588, 14);
            this.dtpDia.Name = "dtpDia";
            this.dtpDia.Size = new System.Drawing.Size(141, 24);
            this.dtpDia.TabIndex = 258;
            // 
            // dtpFim
            // 
            this.dtpFim.CustomFormat = "HH:mm:ss";
            this.dtpFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFim.Location = new System.Drawing.Point(588, 76);
            this.dtpFim.Name = "dtpFim";
            this.dtpFim.ShowUpDown = true;
            this.dtpFim.Size = new System.Drawing.Size(141, 24);
            this.dtpFim.TabIndex = 257;
            this.dtpFim.Value = new System.DateTime(2019, 5, 7, 22, 30, 0, 0);
            // 
            // dtpInicio
            // 
            this.dtpInicio.CustomFormat = "HH:mm:ss";
            this.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInicio.Location = new System.Drawing.Point(588, 42);
            this.dtpInicio.Name = "dtpInicio";
            this.dtpInicio.ShowUpDown = true;
            this.dtpInicio.Size = new System.Drawing.Size(141, 24);
            this.dtpInicio.TabIndex = 256;
            this.dtpInicio.Value = new System.DateTime(2019, 5, 6, 19, 0, 0, 0);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGreen;
            this.label5.Location = new System.Drawing.Point(463, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 18);
            this.label5.TabIndex = 255;
            this.label5.Text = "Término da Aula:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(484, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 18);
            this.label4.TabIndex = 254;
            this.label4.Text = "Início da Aula:";
            // 
            // lstMaterias
            // 
            this.lstMaterias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lstMaterias.FormattingEnabled = true;
            this.lstMaterias.ItemHeight = 18;
            this.lstMaterias.Location = new System.Drawing.Point(65, 9);
            this.lstMaterias.Name = "lstMaterias";
            this.lstMaterias.Size = new System.Drawing.Size(205, 94);
            this.lstMaterias.TabIndex = 248;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(-2, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 18);
            this.label2.TabIndex = 11;
            this.label2.Text = "Matérias:";
            // 
            // panelCurso
            // 
            this.panelCurso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCurso.Controls.Add(this.label9);
            this.panelCurso.Controls.Add(this.lstSemestre);
            this.panelCurso.Controls.Add(this.label6);
            this.panelCurso.Controls.Add(this.lstCurso);
            this.panelCurso.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.panelCurso.Location = new System.Drawing.Point(7, 47);
            this.panelCurso.Name = "panelCurso";
            this.panelCurso.Size = new System.Drawing.Size(745, 112);
            this.panelCurso.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkGreen;
            this.label9.Location = new System.Drawing.Point(596, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 18);
            this.label9.TabIndex = 32;
            this.label9.Text = "Semestre:";
            // 
            // lstSemestre
            // 
            this.lstSemestre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lstSemestre.FormattingEnabled = true;
            this.lstSemestre.ItemHeight = 18;
            this.lstSemestre.Location = new System.Drawing.Point(678, 7);
            this.lstSemestre.Name = "lstSemestre";
            this.lstSemestre.Size = new System.Drawing.Size(50, 94);
            this.lstSemestre.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkGreen;
            this.label6.Location = new System.Drawing.Point(2, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 18);
            this.label6.TabIndex = 30;
            this.label6.Text = "Cursos:";
            // 
            // lstCurso
            // 
            this.lstCurso.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lstCurso.FormattingEnabled = true;
            this.lstCurso.ItemHeight = 18;
            this.lstCurso.Location = new System.Drawing.Point(63, 5);
            this.lstCurso.Name = "lstCurso";
            this.lstCurso.Size = new System.Drawing.Size(205, 94);
            this.lstCurso.TabIndex = 27;
            this.lstCurso.SelectedIndexChanged += new System.EventHandler(this.lstCurso_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.panel1.Controls.Add(this.lblIFSP);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(838, 79);
            this.panel1.TabIndex = 218;
            // 
            // lblIFSP
            // 
            this.lblIFSP.ActiveBorderThickness = 1;
            this.lblIFSP.ActiveCornerRadius = 20;
            this.lblIFSP.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.ActiveForecolor = System.Drawing.Color.Black;
            this.lblIFSP.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.lblIFSP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lblIFSP.BackgroundImage")));
            this.lblIFSP.ButtonText = "Instituto Federal de São Paulo - Campus Capivari";
            this.lblIFSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIFSP.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIFSP.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleBorderThickness = 1;
            this.lblIFSP.IdleCornerRadius = 20;
            this.lblIFSP.IdleFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleForecolor = System.Drawing.Color.Transparent;
            this.lblIFSP.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.Location = new System.Drawing.Point(150, 19);
            this.lblIFSP.Margin = new System.Windows.Forms.Padding(5);
            this.lblIFSP.Name = "lblIFSP";
            this.lblIFSP.Size = new System.Drawing.Size(539, 41);
            this.lblIFSP.TabIndex = 205;
            this.lblIFSP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIFSP.Click += new System.EventHandler(this.lblIFSP_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // gbxOpcoes
            // 
            this.gbxOpcoes.Controls.Add(this.lblSalvar);
            this.gbxOpcoes.Controls.Add(this.btnSalvar);
            this.gbxOpcoes.Controls.Add(this.lblCancelar);
            this.gbxOpcoes.Controls.Add(this.lblEditar);
            this.gbxOpcoes.Controls.Add(this.lblAdicionar);
            this.gbxOpcoes.Controls.Add(this.btnRight);
            this.gbxOpcoes.Controls.Add(this.btnCancelar);
            this.gbxOpcoes.Controls.Add(this.btnLeft);
            this.gbxOpcoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.gbxOpcoes.Location = new System.Drawing.Point(760, 80);
            this.gbxOpcoes.Name = "gbxOpcoes";
            this.gbxOpcoes.Size = new System.Drawing.Size(78, 418);
            this.gbxOpcoes.TabIndex = 219;
            this.gbxOpcoes.TabStop = false;
            this.gbxOpcoes.Text = "Opções";
            // 
            // lblSalvar
            // 
            this.lblSalvar.AutoSize = true;
            this.lblSalvar.BackColor = System.Drawing.Color.Transparent;
            this.lblSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSalvar.Location = new System.Drawing.Point(-7, 298);
            this.lblSalvar.Name = "lblSalvar";
            this.lblSalvar.Size = new System.Drawing.Size(89, 18);
            this.lblSalvar.TabIndex = 254;
            this.lblSalvar.Text = "      &Salvar    ";
            this.lblSalvar.Click += new System.EventHandler(this.lblSalvar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.Location = new System.Drawing.Point(11, 248);
            this.btnSalvar.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(56, 51);
            this.btnSalvar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSalvar.TabIndex = 253;
            this.btnSalvar.TabStop = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // lblCancelar
            // 
            this.lblCancelar.AutoSize = true;
            this.lblCancelar.BackColor = System.Drawing.Color.Transparent;
            this.lblCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCancelar.Location = new System.Drawing.Point(-14, 398);
            this.lblCancelar.Name = "lblCancelar";
            this.lblCancelar.Size = new System.Drawing.Size(91, 18);
            this.lblCancelar.TabIndex = 251;
            this.lblCancelar.Text = "     &Cancelar ";
            // 
            // lblEditar
            // 
            this.lblEditar.AutoSize = true;
            this.lblEditar.BackColor = System.Drawing.Color.Transparent;
            this.lblEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblEditar.Location = new System.Drawing.Point(6, 191);
            this.lblEditar.Name = "lblEditar";
            this.lblEditar.Size = new System.Drawing.Size(64, 18);
            this.lblEditar.TabIndex = 249;
            this.lblEditar.Text = "Proximo";
            this.lblEditar.Click += new System.EventHandler(this.lblEditar_Click);
            // 
            // lblAdicionar
            // 
            this.lblAdicionar.AutoSize = true;
            this.lblAdicionar.BackColor = System.Drawing.Color.Transparent;
            this.lblAdicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAdicionar.Location = new System.Drawing.Point(15, 80);
            this.lblAdicionar.Name = "lblAdicionar";
            this.lblAdicionar.Size = new System.Drawing.Size(46, 18);
            this.lblAdicionar.TabIndex = 248;
            this.lblAdicionar.Text = "Voltar";
            // 
            // FrmReservaSala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(838, 500);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbxDados);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.gbxOpcoes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FrmReservaSala";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReservaSalacs";
            this.Load += new System.EventHandler(this.ReservaSala_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnCancelar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLeft)).EndInit();
            this.gbxDados.ResumeLayout(false);
            this.gbxDados.PerformLayout();
            this.panelSala.ResumeLayout(false);
            this.panelSala.PerformLayout();
            this.panelMateria.ResumeLayout(false);
            this.panelMateria.PerformLayout();
            this.panelCurso.ResumeLayout(false);
            this.panelCurso.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.gbxOpcoes.ResumeLayout(false);
            this.gbxOpcoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSalvar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox btnCancelar;
        private System.Windows.Forms.PictureBox btnRight;
        private System.Windows.Forms.PictureBox btnLeft;
        private System.Windows.Forms.GroupBox gbxDados;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox gbxOpcoes;
        private Bunifu.Framework.UI.BunifuThinButton2 lblIFSP;
        private System.Windows.Forms.Label lblCancelar;
        private System.Windows.Forms.Label lblEditar;
        private System.Windows.Forms.Label lblAdicionar;
        private System.Windows.Forms.Panel panelCurso;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox lstSemestre;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox lstCurso;
        private System.Windows.Forms.Panel panelSala;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstSalas;
        private System.Windows.Forms.Panel panelMateria;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtpDia;
        private System.Windows.Forms.DateTimePicker dtpFim;
        private System.Windows.Forms.DateTimePicker dtpInicio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lstMaterias;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lstProfessor;
        private System.Windows.Forms.Label lblSalvar;
        private System.Windows.Forms.PictureBox btnSalvar;
        private System.Windows.Forms.RadioButton rbtAbrev;
        private System.Windows.Forms.RadioButton rbtNome;
        private System.Windows.Forms.Label lblMessagem;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace TIND
{
    public partial class FrmReservaSala : Form
    {
        public FrmReservaSala()
        {
            InitializeComponent();
            telainicial();            
            this.Text = "Agendamento de Aula";
        }

        Stack<string> pilha = new Stack<string>();
        Aula aula = new Aula();   
        public void telainicial()
        {          
            dtpDia.Text = DateTime.Now.ToString();                      
            alterarTamanhoLst(); 
                        
            
            btnLeft.Enabled = false;            
            btnRight.Enabled = true;
            btnCancelar.Enabled = true;
            btnSalvar.Enabled = false;
           

            pilha.Clear();
            pilha.Push("curso");
                        
            panelMateria.Visible = false;
            panelSala.Visible = false;
            panelCurso.Enabled = true;
        }

        public void carregarListBox(string valor, ListBox lst, string sp)
        {
            Conexao conexao = new Conexao();
            try
            {
                conexao.conectar();
                SqlCommand cmd = new SqlCommand(sp, conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                
                if (sp == "sp_SelMatEspCurSem")
                {
                    int semestre = 0, curso = 0;
                    try
                    {
                        semestre = int.Parse(lstSemestre.Text);
                        curso = int.Parse(lstCurso.SelectedValue.ToString());
                    }
                    catch
                    { }
                    cmd.Parameters.AddWithValue("@pSemestre", semestre);
                    cmd.Parameters.AddWithValue("@pCurso", curso);
                }


                else if (sp == "sp_SelSalEsp" || sp == "sp_SelProfEsp")
                {
                    cmd.Parameters.AddWithValue("@pDataInicio", concatData(dtpDia.Value, dtpInicio.Value));
                    cmd.Parameters.AddWithValue("@pDataFim", concatData(dtpDia.Value, dtpFim.Value));
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();                
                da.Fill(dt);
                lst.DisplayMember = valor;
                lst.ValueMember = "Id";
                lst.DataSource = dt;             


                //if (lst.Items.Count == 0 && pilha.Count !=0)
                 //   MessageBox.Show("Nehuma Informação Encontrada\nCom os Dados Fornecidos\nClique em Voltar e Selecione Outra Opção", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                falhaNoBanco(ex.ToString(), "Buscar Dados");
            }
            finally
            {
                conexao.desconectar();
            }
        }

        private void carregarSemestre()
        {
            try
            {
                int maior = Materia.maiorSemestre(int.Parse(lstCurso.SelectedValue.ToString()));
                lstSemestre.Items.Clear();

                for (int i = 1; i <= maior; i++)
                {
                    lstSemestre.Items.Add(i.ToString());
                }
            }
            catch
            { }
        }

        private void leberarPanel()
        {
            if (lstCurso.SelectedItem != null && lstSemestre.SelectedItem != null)
            {
                alterarTamanhoLst();
                panelMateria.Visible = true;                
            }
        }

        private void alterarTamanhoLst()
        {
            if (rbtNome.Checked == true)
            {
                lstCurso.Size = new System.Drawing.Size(471, 76);
                lstMaterias.Size = new System.Drawing.Size(371, 94);
                lstSalas.Size = new System.Drawing.Size(371, 94);
                carregarListBox("Nome", lstMaterias, "sp_SelMatEspCurSem");
                carregarListBox("Nome", lstCurso, "sp_SelCurso");                
                carregarListBox("Nome", lstSalas, "sp_SelSalEsp");                
            }
            else
            {
                lstCurso.Size = new System.Drawing.Size(146, 76);
                lstMaterias.Size = new System.Drawing.Size(205, 94);
                lstSalas.Size = new System.Drawing.Size(205, 94);
                carregarListBox("Abrev", lstMaterias, "sp_SelMatEspCurSem"); 
                carregarListBox("Abrev", lstCurso, "sp_SelCurso");                                   
                carregarListBox("Abrev", lstSalas, "sp_SelSalEsp");                
            }            
        }

        public bool verificarCampos()
        {
            bool verificar = true;

            string erros = string.Empty;

            if (panelMateria.Visible == false && panelSala.Visible == false)
            {
                if (lstCurso.SelectedItem == null)
                    erros = "--Selecione o Curso\n";
                if (lstSemestre.SelectedItem == null)
                    erros = "--Selecione o Semestre\n";
                if (erros != string.Empty)
                    verificar = false;
            }
            else if (panelSala.Visible == false)
            {
                if (lstMaterias.SelectedItem == null)
                {
                    erros = "--Selecione a Materia\n";
                    verificar = false;
                }
            }
            else
            {
                if (lstSalas.SelectedItem == null)
                    erros = "--Selecione a Sala\n";
                if (lstProfessor.SelectedItem == null)
                    erros = "--Selecione o Professor\n";
                if (erros != string.Empty)
                    verificar = false;
            }

            if (erros != string.Empty)
                if (erros.Length > 26)
                    MessageBox.Show(erros, "Antenção Corrija Os Seguintes Erros", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show(erros, "Antenção Corrija O Seguinte Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            return verificar;
        }

        private void salvarDados()
        {
            if (verificarCampos())
            {
                string resul = string.Empty;

                aula.idSala = int.Parse(lstSalas.SelectedValue.ToString());
                aula.idMateria = int.Parse(lstMaterias.SelectedValue.ToString());
                aula.idProfessor = int.Parse(lstProfessor.SelectedValue.ToString());
                aula.dataInicio = concatData(dtpDia.Value, dtpInicio.Value);
                aula.dataFim = concatData(dtpDia.Value, dtpFim.Value);

                resul = Aula.setAula(aula);

                if (resul == "")
                    messagem("Aula Agendada Com Sucesso");
                else
                    falhaNoBanco(resul, "Salvar Aula");

                telainicial();
            }
        }

        private async void messagem(string messagem)
        {
            lblMessagem.Text = messagem;
            lblMessagem.Visible = true;           
        
            await Task.Delay(1500);
            lblMessagem.Visible = false;                
        }

        private void falhaNoBanco(string falha, string onde)
        {
            if (MessageBox.Show("Erro Ao Tentar " + onde + " No Banco de Dados\n\nClique Sim Para Ver a \nDescrição Completa do Erro", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Error).ToString().ToUpper() == "YES")
                MessageBox.Show(falha, "Descrição Completa do Erro", MessageBoxButtons.OK);
        }

        private void ReservaSala_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'tINDIFSPDataSet.professor' table. You can move, or remove it, as needed.
            //this.professorTableAdapter.Fill(this.tINDIFSPDataSet.professor);
            //telainicial();

        }

        private DateTime concatData(DateTime Datadia, DateTime hora)
        {
            DateTime resultado = new DateTime();
            
            int dia = Datadia.Day;
            int mes = Datadia.Month;
            int ano = Datadia.Year;

            string data = dia.ToString() + "/" + mes.ToString() + "/" + ano.ToString();

            resultado = Convert.ToDateTime(data);

            double horaD = hora.Hour;
            double minuto = hora.Minute;
            resultado = resultado.AddHours(horaD);
            resultado = resultado.AddMinutes(minuto);
            return (resultado);
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            MessageBox.Show("fs");
            
            if (verificarCampos())
            {
                if (pilha.Count > 0)
                    if (pilha.Peek() == "sala")
                        salvarDados();
                if (pilha.Peek() == "curso")
                {                   
                    panelMateria.Visible = true;
                    panelMateria.Enabled = true;
                    pilha.Push("materia");
                    panelCurso.Enabled = false;                     
                    alterarTamanhoLst();
                }
                else if (pilha.Peek() == "materia")
                {
                    if (rbtAbrev.Checked == true)
                        carregarListBox("Abrev", lstSalas, "sp_SelSalEsp");
                    else
                        carregarListBox("Nome", lstSalas, "sp_SelSalEsp");                    
                    carregarListBox("Nome", lstProfessor, "sp_SelProfEsp");
                    panelSala.Visible = true;
                    pilha.Push("sala");
                    panelMateria.Enabled = false;
                    btnSalvar.Enabled = true;
                }               

                btnLeft.Enabled = true;             
            }
        } 
        
        private void btnCancelar_Click(object sender, EventArgs e)
        {          
            telainicial();
        }    

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            salvarDados();
        }

        private void checkedRbts(object sender, EventArgs e)
        {
            alterarTamanhoLst();
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            switch(pilha.Pop())
            {
                case "curso":
                    telainicial();
                    break;

                case "materia":
                    panelMateria.Visible = false;
                    panelCurso.Enabled = true;
                    break;

                case "sala":
                    panelSala.Visible = false;
                    panelMateria.Enabled = true;
                    break;                   
            }
        }

        private void lblIFSP_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cpv.ifsp.edu.br/");
        }

        private void lstCurso_SelectedIndexChanged(object sender, EventArgs e)
        {
            carregarSemestre();
        }

        private void lblEditar_Click(object sender, EventArgs e)
        {

        }

        private void lblSalvar_Click(object sender, EventArgs e)
        {

        }           
    }
}  


﻿namespace TIND
{
    partial class FrmSalasReservadas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSalasReservadas));
            this.lblIFSP = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblMessagem = new System.Windows.Forms.Label();
            this.btnBuscar = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtpDia = new System.Windows.Forms.DateTimePicker();
            this.rbtDia = new System.Windows.Forms.RadioButton();
            this.rbtHora = new System.Windows.Forms.RadioButton();
            this.panelHoras = new System.Windows.Forms.Panel();
            this.dtpFim = new System.Windows.Forms.DateTimePicker();
            this.dtpInicio = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gridAula = new System.Windows.Forms.DataGridView();
            this.btnExcluir = new System.Windows.Forms.PictureBox();
            this.lblExcluir = new System.Windows.Forms.Label();
            this.txtMateria = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtProfessor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSala = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.gbxDados = new System.Windows.Forms.GroupBox();
            this.txtFimAula = new System.Windows.Forms.TextBox();
            this.txtInicioAula = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).BeginInit();
            this.panelHoras.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridAula)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExcluir)).BeginInit();
            this.gbxDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblIFSP
            // 
            this.lblIFSP.ActiveBorderThickness = 1;
            this.lblIFSP.ActiveCornerRadius = 20;
            this.lblIFSP.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.ActiveForecolor = System.Drawing.Color.Black;
            this.lblIFSP.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.lblIFSP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lblIFSP.BackgroundImage")));
            this.lblIFSP.ButtonText = "Instituto Federal de São Paulo - Campus Capivari";
            this.lblIFSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIFSP.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIFSP.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleBorderThickness = 1;
            this.lblIFSP.IdleCornerRadius = 20;
            this.lblIFSP.IdleFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleForecolor = System.Drawing.Color.Transparent;
            this.lblIFSP.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.Location = new System.Drawing.Point(150, 19);
            this.lblIFSP.Margin = new System.Windows.Forms.Padding(5);
            this.lblIFSP.Name = "lblIFSP";
            this.lblIFSP.Size = new System.Drawing.Size(539, 41);
            this.lblIFSP.TabIndex = 204;
            this.lblIFSP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIFSP.Click += new System.EventHandler(this.lblIFSP_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.panel1.Controls.Add(this.lblIFSP);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(881, 79);
            this.panel1.TabIndex = 249;
            // 
            // lblMessagem
            // 
            this.lblMessagem.AutoSize = true;
            this.lblMessagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessagem.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblMessagem.Location = new System.Drawing.Point(286, 124);
            this.lblMessagem.Name = "lblMessagem";
            this.lblMessagem.Size = new System.Drawing.Size(268, 24);
            this.lblMessagem.TabIndex = 252;
            this.lblMessagem.Text = "Registro inserido com sucesso";
            this.lblMessagem.Visible = false;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Image = ((System.Drawing.Image)(resources.GetObject("btnBuscar.Image")));
            this.btnBuscar.Location = new System.Drawing.Point(794, 89);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(2);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(40, 33);
            this.btnBuscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnBuscar.TabIndex = 24;
            this.btnBuscar.TabStop = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkGreen;
            this.label11.Location = new System.Drawing.Point(7, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 18);
            this.label11.TabIndex = 265;
            this.label11.Text = "Dia da Aula:";
            // 
            // dtpDia
            // 
            this.dtpDia.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDia.Location = new System.Drawing.Point(93, 93);
            this.dtpDia.Name = "dtpDia";
            this.dtpDia.Size = new System.Drawing.Size(141, 20);
            this.dtpDia.TabIndex = 264;
            // 
            // rbtDia
            // 
            this.rbtDia.AutoSize = true;
            this.rbtDia.Checked = true;
            this.rbtDia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtDia.ForeColor = System.Drawing.Color.DarkGreen;
            this.rbtDia.Location = new System.Drawing.Point(12, 115);
            this.rbtDia.Name = "rbtDia";
            this.rbtDia.Size = new System.Drawing.Size(51, 24);
            this.rbtDia.TabIndex = 271;
            this.rbtDia.TabStop = true;
            this.rbtDia.Text = "Dia";
            this.rbtDia.UseVisualStyleBackColor = true;
            this.rbtDia.CheckedChanged += new System.EventHandler(this.rbtDia_CheckedChanged);
            // 
            // rbtHora
            // 
            this.rbtHora.AutoSize = true;
            this.rbtHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtHora.ForeColor = System.Drawing.Color.DarkGreen;
            this.rbtHora.Location = new System.Drawing.Point(93, 115);
            this.rbtHora.Name = "rbtHora";
            this.rbtHora.Size = new System.Drawing.Size(103, 24);
            this.rbtHora.TabIndex = 272;
            this.rbtHora.Text = "Dia e Hora";
            this.rbtHora.UseVisualStyleBackColor = true;
            this.rbtHora.CheckedChanged += new System.EventHandler(this.rbtHora_CheckedChanged);
            // 
            // panelHoras
            // 
            this.panelHoras.Controls.Add(this.dtpFim);
            this.panelHoras.Controls.Add(this.dtpInicio);
            this.panelHoras.Controls.Add(this.label1);
            this.panelHoras.Controls.Add(this.label4);
            this.panelHoras.Location = new System.Drawing.Point(240, 90);
            this.panelHoras.Name = "panelHoras";
            this.panelHoras.Size = new System.Drawing.Size(533, 29);
            this.panelHoras.TabIndex = 273;
            this.panelHoras.Visible = false;
            // 
            // dtpFim
            // 
            this.dtpFim.CustomFormat = "HH:mm:ss";
            this.dtpFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFim.Location = new System.Drawing.Point(377, 3);
            this.dtpFim.Name = "dtpFim";
            this.dtpFim.ShowUpDown = true;
            this.dtpFim.Size = new System.Drawing.Size(141, 20);
            this.dtpFim.TabIndex = 267;
            this.dtpFim.Value = new System.DateTime(2019, 5, 7, 22, 30, 0, 0);
            // 
            // dtpInicio
            // 
            this.dtpInicio.CustomFormat = "HH:mm:ss";
            this.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInicio.Location = new System.Drawing.Point(102, 3);
            this.dtpInicio.Name = "dtpInicio";
            this.dtpInicio.ShowUpDown = true;
            this.dtpInicio.Size = new System.Drawing.Size(141, 20);
            this.dtpInicio.TabIndex = 266;
            this.dtpInicio.Value = new System.DateTime(2019, 5, 6, 19, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(263, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 18);
            this.label1.TabIndex = 265;
            this.label1.Text = "Término da Aula:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(3, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 18);
            this.label4.TabIndex = 264;
            this.label4.Text = "Início da Aula:";
            // 
            // gridAula
            // 
            this.gridAula.AllowUserToAddRows = false;
            this.gridAula.AllowUserToDeleteRows = false;
            this.gridAula.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridAula.Location = new System.Drawing.Point(12, 151);
            this.gridAula.MultiSelect = false;
            this.gridAula.Name = "gridAula";
            this.gridAula.ReadOnly = true;
            this.gridAula.RowHeadersVisible = false;
            this.gridAula.Size = new System.Drawing.Size(806, 167);
            this.gridAula.TabIndex = 274;
            this.gridAula.DoubleClick += new System.EventHandler(this.carregarDadosAula);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.Location = new System.Drawing.Point(762, 337);
            this.btnExcluir.Margin = new System.Windows.Forms.Padding(2);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(56, 51);
            this.btnExcluir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnExcluir.TabIndex = 269;
            this.btnExcluir.TabStop = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // lblExcluir
            // 
            this.lblExcluir.AutoSize = true;
            this.lblExcluir.BackColor = System.Drawing.Color.Transparent;
            this.lblExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblExcluir.Location = new System.Drawing.Point(750, 390);
            this.lblExcluir.Name = "lblExcluir";
            this.lblExcluir.Size = new System.Drawing.Size(68, 13);
            this.lblExcluir.TabIndex = 270;
            this.lblExcluir.Text = "      E&xcluir    ";
            // 
            // txtMateria
            // 
            this.txtMateria.Location = new System.Drawing.Point(93, 33);
            this.txtMateria.Name = "txtMateria";
            this.txtMateria.ReadOnly = true;
            this.txtMateria.Size = new System.Drawing.Size(288, 24);
            this.txtMateria.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(7, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 18);
            this.label2.TabIndex = 13;
            this.label2.Text = "Materia:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(6, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 20);
            this.label3.TabIndex = 257;
            this.label3.Text = "Professor:";
            // 
            // txtProfessor
            // 
            this.txtProfessor.Location = new System.Drawing.Point(93, 70);
            this.txtProfessor.Name = "txtProfessor";
            this.txtProfessor.ReadOnly = true;
            this.txtProfessor.Size = new System.Drawing.Size(288, 24);
            this.txtProfessor.TabIndex = 258;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGreen;
            this.label5.Location = new System.Drawing.Point(12, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 18);
            this.label5.TabIndex = 259;
            this.label5.Text = "Sala:";
            // 
            // txtSala
            // 
            this.txtSala.Location = new System.Drawing.Point(93, 114);
            this.txtSala.Name = "txtSala";
            this.txtSala.ReadOnly = true;
            this.txtSala.Size = new System.Drawing.Size(288, 24);
            this.txtSala.TabIndex = 260;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkGreen;
            this.label8.Location = new System.Drawing.Point(427, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 18);
            this.label8.TabIndex = 261;
            this.label8.Text = "Início da Aula:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkGreen;
            this.label7.Location = new System.Drawing.Point(406, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 18);
            this.label7.TabIndex = 262;
            this.label7.Text = "Término da Aula:";
            // 
            // gbxDados
            // 
            this.gbxDados.Controls.Add(this.txtFimAula);
            this.gbxDados.Controls.Add(this.txtInicioAula);
            this.gbxDados.Controls.Add(this.label7);
            this.gbxDados.Controls.Add(this.label8);
            this.gbxDados.Controls.Add(this.txtSala);
            this.gbxDados.Controls.Add(this.label5);
            this.gbxDados.Controls.Add(this.txtProfessor);
            this.gbxDados.Controls.Add(this.label3);
            this.gbxDados.Controls.Add(this.label2);
            this.gbxDados.Controls.Add(this.txtMateria);
            this.gbxDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.gbxDados.ForeColor = System.Drawing.Color.DarkGreen;
            this.gbxDados.Location = new System.Drawing.Point(10, 324);
            this.gbxDados.Name = "gbxDados";
            this.gbxDados.Size = new System.Drawing.Size(747, 164);
            this.gbxDados.TabIndex = 266;
            this.gbxDados.TabStop = false;
            this.gbxDados.Text = "Dados da Aula:";
            // 
            // txtFimAula
            // 
            this.txtFimAula.Location = new System.Drawing.Point(531, 111);
            this.txtFimAula.Name = "txtFimAula";
            this.txtFimAula.ReadOnly = true;
            this.txtFimAula.Size = new System.Drawing.Size(202, 24);
            this.txtFimAula.TabIndex = 266;
            // 
            // txtInicioAula
            // 
            this.txtInicioAula.Location = new System.Drawing.Point(531, 33);
            this.txtInicioAula.Name = "txtInicioAula";
            this.txtInicioAula.ReadOnly = true;
            this.txtInicioAula.Size = new System.Drawing.Size(210, 24);
            this.txtInicioAula.TabIndex = 265;
            // 
            // FrmSalasReservadas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(836, 496);
            this.Controls.Add(this.gridAula);
            this.Controls.Add(this.panelHoras);
            this.Controls.Add(this.rbtHora);
            this.Controls.Add(this.rbtDia);
            this.Controls.Add(this.lblExcluir);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.gbxDados);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.dtpDia);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblMessagem);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSalasReservadas";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmSalasReservadas";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).EndInit();
            this.panelHoras.ResumeLayout(false);
            this.panelHoras.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridAula)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExcluir)).EndInit();
            this.gbxDados.ResumeLayout(false);
            this.gbxDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 lblIFSP;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblMessagem;
        private System.Windows.Forms.PictureBox btnBuscar;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtpDia;
        private System.Windows.Forms.RadioButton rbtDia;
        private System.Windows.Forms.RadioButton rbtHora;
        private System.Windows.Forms.Panel panelHoras;
        private System.Windows.Forms.DateTimePicker dtpFim;
        private System.Windows.Forms.DateTimePicker dtpInicio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView gridAula;
        private System.Windows.Forms.PictureBox btnExcluir;
        private System.Windows.Forms.Label lblExcluir;
        private System.Windows.Forms.TextBox txtMateria;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtProfessor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSala;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox gbxDados;
        private System.Windows.Forms.TextBox txtFimAula;
        private System.Windows.Forms.TextBox txtInicioAula;

    }
}
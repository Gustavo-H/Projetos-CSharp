﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TIND
{
    public partial class FrmSalasReservadas : Form
    {
        public FrmSalasReservadas()
        {
            InitializeComponent();
            telaInicial();
            this.Text = "Aulas Agendadas";
        }

        int idAula = 0;

        private void telaInicial()
        {
            dtpDia.Value = DateTime.Now;
            if (rbtDia.Checked == true)
                carregarMaterias("sp_SelAulaDia");
            else
                carregarMaterias("sp_SelAulaHora");
            btnExcluir.Enabled = false;
            txtFimAula.Text = string.Empty;
            txtInicioAula.Text = string.Empty;
            txtMateria.Text = string.Empty;
            txtProfessor.Text = string.Empty;
            txtSala.Text = string.Empty;
        }

        public void carregarMaterias(string sp)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand(sp, conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                if (rbtDia.Checked == true)
                {
                    cmd.Parameters.AddWithValue("@pDiaInicio", Convert.ToDateTime(dtpDia.Value.ToShortDateString()));
                }
                else
                {
                    cmd.Parameters.AddWithValue("@pDataInicio", concatData(dtpDia.Value, dtpInicio.Value));
                    cmd.Parameters.AddWithValue("@pDataFim", concatData(dtpDia.Value, dtpFim.Value));
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                conexao.desconectar();
                gridAula.DataSource = ds.Tables[0];
                gridAula.AutoResizeColumns();

                gridAula.ReadOnly = true;
                gridAula.Columns[0].HeaderText = "ID";
                gridAula.Columns[1].HeaderText = "Professor";
                gridAula.Columns[2].HeaderText = "Materia";
                gridAula.Columns[3].HeaderText = "Sala";
                gridAula.Columns[4].HeaderText = "Inicio";
                gridAula.Columns[5].HeaderText = "Fim";


                gridAula.Columns[0].Visible = false;
                gridAula.Columns[0].Width = 0;

                gridAula.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                gridAula.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception ex)
            {
                falhaNoBanco(ex.ToString(), "Buscar Dados");
            }
        }

        private DateTime concatData(DateTime Datadia, DateTime hora)
        {
            DateTime resultado = new DateTime();

            int dia = Datadia.Day;
            int mes = Datadia.Month;
            int ano = Datadia.Year;

            string data = dia.ToString() + "/" + mes.ToString() + "/" + ano.ToString();

            resultado = Convert.ToDateTime(data);

            double horaD = hora.Hour;
            double minuto = hora.Minute;
            resultado = resultado.AddHours(horaD);
            resultado = resultado.AddMinutes(minuto);
            return (resultado);
        }

        private async void messagem(string messagem)
        {
            lblMessagem.Text = messagem;
            lblMessagem.Visible = true;

            await Task.Delay(1500);
            lblMessagem.Visible = false;
        }

        private void falhaNoBanco(string falha, string onde)
        {
            if (MessageBox.Show("Erro Ao Tentar " + onde + " No Banco de Dados\n\nClique Sim Para Ver a \nDescrição Completa do Erro", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Error).ToString().ToUpper() == "YES")
                MessageBox.Show(falha, "Descrição Completa do Erro", MessageBoxButtons.OK);
        }

        private void rbtHora_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtHora.Checked == true)
                panelHoras.Visible = true;
            else
                panelHoras.Visible = false;
        }

        private void rbtDia_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtDia.Checked == true)
                panelHoras.Visible = false;
            else
                panelHoras.Visible = true;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (rbtDia.Checked == true)
                carregarMaterias("sp_SelAulaDia");
            else
                carregarMaterias("sp_SelAulaHora");
        }

        private void carregarDadosAula(object sender, EventArgs e)
        {
            Aula aula = Aula.getAula(Convert.ToInt32(gridAula.CurrentRow.Cells[0].Value));
            if (aula != null)
            {
                idAula = Convert.ToInt32(gridAula.CurrentRow.Cells[0].Value);
                txtMateria.Text = aula.nomeMateria;
                txtProfessor.Text = aula.nomeProfessor;
                txtSala.Text = aula.nomeSala;
                txtInicioAula.Text = aula.dataInicio.ToString();
                txtFimAula.Text = aula.dataFim.ToString();
                btnExcluir.Enabled = true;
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (idAula != 0)
                if (MessageBox.Show("Esta Aula Será Apagada do Banco de Dados\nVoçê Tem Certeza Que Deseja Prossegui Com a Ação?", "ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2).ToString().ToUpper() == "YES")
                {
                    string result = string.Empty;

                    result = Aula.delAula(idAula);
                    if (result == "")
                        messagem("Aula Excuida com Sucesso");
                    else
                        falhaNoBanco(result, "Excluir Aula");

                    telaInicial();
                }
        }

        private void lblIFSP_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cpv.ifsp.edu.br/");
        }
    }
}

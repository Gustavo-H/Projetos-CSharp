﻿namespace TIND
{
    partial class FrmVizualizarSala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmVizualizarSala));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblData = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblHorario = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.TopControl = new System.Windows.Forms.Panel();
            this.lblIFSP = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnDesMaximizar = new System.Windows.Forms.PictureBox();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.btnMaximizar = new System.Windows.Forms.PictureBox();
            this.btnSair = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblSala = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblProfessor = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMateria = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblHoraInicio = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblHoraFim = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panelAula = new System.Windows.Forms.Panel();
            this.lblProximo = new System.Windows.Forms.Label();
            this.panelSalaDisponivel = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblNomeSalasSemAula = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblNehumaSala = new System.Windows.Forms.Label();
            this.lblSalaComAula = new System.Windows.Forms.Label();
            this.lblSalaSemAula = new System.Windows.Forms.Label();
            this.TopControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDesMaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelAula.SuspendLayout();
            this.panelSalaDisponivel.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("fm3", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblData.Location = new System.Drawing.Point(7, 9);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(60, 25);
            this.lblData.TabIndex = 220;
            this.lblData.Text = "Data";
            // 
            // lblHorario
            // 
            this.lblHorario.AutoSize = true;
            this.lblHorario.BackColor = System.Drawing.Color.Transparent;
            this.lblHorario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblHorario.Font = new System.Drawing.Font("fm3", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHorario.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblHorario.Location = new System.Drawing.Point(156, 9);
            this.lblHorario.Name = "lblHorario";
            this.lblHorario.Size = new System.Drawing.Size(92, 25);
            this.lblHorario.TabIndex = 221;
            this.lblHorario.Text = "Horario";
            // 
            // TopControl
            // 
            this.TopControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.TopControl.Controls.Add(this.lblIFSP);
            this.TopControl.Controls.Add(this.pictureBox1);
            this.TopControl.Controls.Add(this.btnDesMaximizar);
            this.TopControl.Controls.Add(this.btnMinimizar);
            this.TopControl.Controls.Add(this.btnMaximizar);
            this.TopControl.Controls.Add(this.btnSair);
            this.TopControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopControl.Location = new System.Drawing.Point(0, 0);
            this.TopControl.Name = "TopControl";
            this.TopControl.Size = new System.Drawing.Size(1103, 80);
            this.TopControl.TabIndex = 233;
            // 
            // lblIFSP
            // 
            this.lblIFSP.ActiveBorderThickness = 1;
            this.lblIFSP.ActiveCornerRadius = 20;
            this.lblIFSP.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.ActiveForecolor = System.Drawing.Color.Black;
            this.lblIFSP.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblIFSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(36)))));
            this.lblIFSP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lblIFSP.BackgroundImage")));
            this.lblIFSP.ButtonText = "Instituto Federal de São Paulo - Campus Capivari";
            this.lblIFSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIFSP.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIFSP.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleBorderThickness = 1;
            this.lblIFSP.IdleCornerRadius = 20;
            this.lblIFSP.IdleFillColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.IdleForecolor = System.Drawing.Color.Transparent;
            this.lblIFSP.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.lblIFSP.Location = new System.Drawing.Point(288, 14);
            this.lblIFSP.Margin = new System.Windows.Forms.Padding(5);
            this.lblIFSP.Name = "lblIFSP";
            this.lblIFSP.Size = new System.Drawing.Size(539, 41);
            this.lblIFSP.TabIndex = 207;
            this.lblIFSP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIFSP.Click += new System.EventHandler(this.lblIFSP_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 206;
            this.pictureBox1.TabStop = false;
            // 
            // btnDesMaximizar
            // 
            this.btnDesMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDesMaximizar.Image = ((System.Drawing.Image)(resources.GetObject("btnDesMaximizar.Image")));
            this.btnDesMaximizar.Location = new System.Drawing.Point(1025, 12);
            this.btnDesMaximizar.Name = "btnDesMaximizar";
            this.btnDesMaximizar.Size = new System.Drawing.Size(30, 30);
            this.btnDesMaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnDesMaximizar.TabIndex = 19;
            this.btnDesMaximizar.TabStop = false;
            this.btnDesMaximizar.Visible = false;
            this.btnDesMaximizar.Click += new System.EventHandler(this.BtnMaximizar_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimizar.Image")));
            this.btnMinimizar.Location = new System.Drawing.Point(989, 12);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(30, 30);
            this.btnMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMinimizar.TabIndex = 18;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.BtnMinimizar_Click);
            // 
            // btnMaximizar
            // 
            this.btnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMaximizar.Image")));
            this.btnMaximizar.Location = new System.Drawing.Point(1025, 12);
            this.btnMaximizar.Name = "btnMaximizar";
            this.btnMaximizar.Size = new System.Drawing.Size(30, 30);
            this.btnMaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMaximizar.TabIndex = 17;
            this.btnMaximizar.TabStop = false;
            this.btnMaximizar.Click += new System.EventHandler(this.BtnMaximizar_Click_1);
            // 
            // btnSair
            // 
            this.btnSair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.Location = new System.Drawing.Point(1061, 12);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(30, 30);
            this.btnSair.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSair.TabIndex = 16;
            this.btnSair.TabStop = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-2, 70);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1105, 551);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 234;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomLabel1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Rudiment", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(32, 362);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(282, 27);
            this.bunifuCustomLabel1.TabIndex = 235;
            this.bunifuCustomLabel1.Text = "Salas De Aulas Disponiveis";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SeaGreen;
            this.label1.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(14, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 32);
            this.label1.TabIndex = 236;
            this.label1.Text = "Sala de Aula : ";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(1103, 621);
            this.shapeContainer1.TabIndex = 237;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.White;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.SelectionColor = System.Drawing.Color.White;
            this.lineShape1.X1 = 374;
            this.lineShape1.X2 = 449;
            this.lineShape1.Y1 = 383;
            this.lineShape1.Y2 = 406;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.lblData);
            this.panel1.Controls.Add(this.lblHorario);
            this.panel1.Controls.Add(this.bunifuCustomLabel2);
            this.panel1.Location = new System.Drawing.Point(813, 89);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(263, 45);
            this.panel1.TabIndex = 238;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("fm3", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.LimeGreen;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(137, 9);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(24, 25);
            this.bunifuCustomLabel2.TabIndex = 239;
            this.bunifuCustomLabel2.Text = "-";
            // 
            // lblSala
            // 
            this.lblSala.AutoSize = true;
            this.lblSala.BackColor = System.Drawing.Color.SeaGreen;
            this.lblSala.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSala.Font = new System.Drawing.Font("Rudiment", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSala.ForeColor = System.Drawing.Color.White;
            this.lblSala.Location = new System.Drawing.Point(216, 28);
            this.lblSala.Name = "lblSala";
            this.lblSala.Size = new System.Drawing.Size(344, 27);
            this.lblSala.TabIndex = 239;
            this.lblSala.Text = "Nome Completo da Sala de Aula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SeaGreen;
            this.label2.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(49, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 32);
            this.label2.TabIndex = 240;
            this.label2.Text = "Professor : ";
            // 
            // lblProfessor
            // 
            this.lblProfessor.AutoSize = true;
            this.lblProfessor.BackColor = System.Drawing.Color.SeaGreen;
            this.lblProfessor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblProfessor.Font = new System.Drawing.Font("Rudiment", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfessor.ForeColor = System.Drawing.Color.White;
            this.lblProfessor.Location = new System.Drawing.Point(216, 85);
            this.lblProfessor.Name = "lblProfessor";
            this.lblProfessor.Size = new System.Drawing.Size(326, 27);
            this.lblProfessor.TabIndex = 241;
            this.lblProfessor.Text = "Nome Completo do Professor";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.SeaGreen;
            this.label3.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(70, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 32);
            this.label3.TabIndex = 242;
            this.label3.Text = "Materia : ";
            // 
            // lblMateria
            // 
            this.lblMateria.AutoSize = true;
            this.lblMateria.BackColor = System.Drawing.Color.SeaGreen;
            this.lblMateria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblMateria.Font = new System.Drawing.Font("Rudiment", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMateria.ForeColor = System.Drawing.Color.White;
            this.lblMateria.Location = new System.Drawing.Point(216, 146);
            this.lblMateria.Name = "lblMateria";
            this.lblMateria.Size = new System.Drawing.Size(295, 27);
            this.lblMateria.TabIndex = 243;
            this.lblMateria.Text = "Nome COmpleto da Materia";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.SeaGreen;
            this.label4.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(105, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 32);
            this.label4.TabIndex = 244;
            this.label4.Text = "Inicio : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.SeaGreen;
            this.label5.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(361, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 32);
            this.label5.TabIndex = 245;
            this.label5.Text = "Fim : ";
            // 
            // lblHoraInicio
            // 
            this.lblHoraInicio.AutoSize = true;
            this.lblHoraInicio.BackColor = System.Drawing.Color.SeaGreen;
            this.lblHoraInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblHoraInicio.Font = new System.Drawing.Font("Rudiment", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoraInicio.ForeColor = System.Drawing.Color.White;
            this.lblHoraInicio.Location = new System.Drawing.Point(216, 210);
            this.lblHoraInicio.Name = "lblHoraInicio";
            this.lblHoraInicio.Size = new System.Drawing.Size(119, 27);
            this.lblHoraInicio.TabIndex = 246;
            this.lblHoraInicio.Text = "HoraInicio";
            // 
            // lblHoraFim
            // 
            this.lblHoraFim.AutoSize = true;
            this.lblHoraFim.BackColor = System.Drawing.Color.SeaGreen;
            this.lblHoraFim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblHoraFim.Font = new System.Drawing.Font("Rudiment", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoraFim.ForeColor = System.Drawing.Color.White;
            this.lblHoraFim.Location = new System.Drawing.Point(478, 210);
            this.lblHoraFim.Name = "lblHoraFim";
            this.lblHoraFim.Size = new System.Drawing.Size(93, 27);
            this.lblHoraFim.TabIndex = 247;
            this.lblHoraFim.Text = "HoraFim";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.SeaGreen;
            this.label6.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(763, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 256);
            this.label6.TabIndex = 249;
            this.label6.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.SeaGreen;
            this.label7.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(-4, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 288);
            this.label7.TabIndex = 250;
            this.label7.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n\r\n";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.SeaGreen;
            this.label9.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(8, -7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(760, 32);
            this.label9.TabIndex = 252;
            this.label9.Text = "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" +
    " - - - - - -";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.SeaGreen;
            this.label8.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(8, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(760, 32);
            this.label8.TabIndex = 253;
            this.label8.Text = "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" +
    " - - - - - -";
            // 
            // panelAula
            // 
            this.panelAula.Controls.Add(this.lblProximo);
            this.panelAula.Controls.Add(this.lblProfessor);
            this.panelAula.Controls.Add(this.label8);
            this.panelAula.Controls.Add(this.label1);
            this.panelAula.Controls.Add(this.label9);
            this.panelAula.Controls.Add(this.lblSala);
            this.panelAula.Controls.Add(this.label7);
            this.panelAula.Controls.Add(this.label2);
            this.panelAula.Controls.Add(this.label6);
            this.panelAula.Controls.Add(this.label3);
            this.panelAula.Controls.Add(this.lblHoraFim);
            this.panelAula.Controls.Add(this.lblMateria);
            this.panelAula.Controls.Add(this.lblHoraInicio);
            this.panelAula.Controls.Add(this.label4);
            this.panelAula.Controls.Add(this.label5);
            this.panelAula.Location = new System.Drawing.Point(23, 88);
            this.panelAula.Name = "panelAula";
            this.panelAula.Size = new System.Drawing.Size(784, 269);
            this.panelAula.TabIndex = 254;
            // 
            // lblProximo
            // 
            this.lblProximo.AutoSize = true;
            this.lblProximo.BackColor = System.Drawing.Color.SeaGreen;
            this.lblProximo.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProximo.ForeColor = System.Drawing.Color.White;
            this.lblProximo.Location = new System.Drawing.Point(669, 215);
            this.lblProximo.Name = "lblProximo";
            this.lblProximo.Size = new System.Drawing.Size(88, 32);
            this.lblProximo.TabIndex = 254;
            this.lblProximo.Text = "- - - - -";
            // 
            // panelSalaDisponivel
            // 
            this.panelSalaDisponivel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panelSalaDisponivel.Controls.Add(this.label13);
            this.panelSalaDisponivel.Controls.Add(this.label12);
            this.panelSalaDisponivel.Controls.Add(this.label11);
            this.panelSalaDisponivel.Controls.Add(this.label10);
            this.panelSalaDisponivel.Controls.Add(this.lblNomeSalasSemAula);
            this.panelSalaDisponivel.Location = new System.Drawing.Point(25, 392);
            this.panelSalaDisponivel.Name = "panelSalaDisponivel";
            this.panelSalaDisponivel.Size = new System.Drawing.Size(1051, 179);
            this.panelSalaDisponivel.TabIndex = 255;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.SeaGreen;
            this.label13.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(3, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 160);
            this.label13.TabIndex = 256;
            this.label13.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.SeaGreen;
            this.label12.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(1030, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 160);
            this.label12.TabIndex = 255;
            this.label12.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.SeaGreen;
            this.label11.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(6, 147);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(1032, 32);
            this.label11.TabIndex = 254;
            this.label11.Text = "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" +
    " - - - - - - - - - - - - - - - - - - - - - - -";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.SeaGreen;
            this.label10.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(3, -7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1048, 32);
            this.label10.TabIndex = 253;
            this.label10.Text = "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" +
    " - - - - - - - - - - - - - - - - - - - - - - - -";
            // 
            // lblNomeSalasSemAula
            // 
            this.lblNomeSalasSemAula.AutoSize = true;
            this.lblNomeSalasSemAula.BackColor = System.Drawing.Color.SeaGreen;
            this.lblNomeSalasSemAula.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNomeSalasSemAula.Font = new System.Drawing.Font("Rudiment", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeSalasSemAula.ForeColor = System.Drawing.Color.White;
            this.lblNomeSalasSemAula.Location = new System.Drawing.Point(26, -6);
            this.lblNomeSalasSemAula.Name = "lblNomeSalasSemAula";
            this.lblNomeSalasSemAula.Size = new System.Drawing.Size(271, 27);
            this.lblNomeSalasSemAula.TabIndex = 244;
            this.lblNomeSalasSemAula.Text = "Salas de Aula Disponiveis";
            // 
            // lblNehumaSala
            // 
            this.lblNehumaSala.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblNehumaSala.AutoSize = true;
            this.lblNehumaSala.BackColor = System.Drawing.Color.SeaGreen;
            this.lblNehumaSala.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNehumaSala.ForeColor = System.Drawing.Color.White;
            this.lblNehumaSala.Location = new System.Drawing.Point(819, 266);
            this.lblNehumaSala.Name = "lblNehumaSala";
            this.lblNehumaSala.Size = new System.Drawing.Size(489, 96);
            this.lblNehumaSala.TabIndex = 258;
            this.lblNehumaSala.Text = "Nenhuma Aula Acontecendo Agora \r\n\r\nTodas As Salas Estão Diponíveis";
            this.lblNehumaSala.Visible = false;
            // 
            // lblSalaComAula
            // 
            this.lblSalaComAula.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSalaComAula.AutoSize = true;
            this.lblSalaComAula.BackColor = System.Drawing.Color.SeaGreen;
            this.lblSalaComAula.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalaComAula.ForeColor = System.Drawing.Color.White;
            this.lblSalaComAula.Location = new System.Drawing.Point(818, 156);
            this.lblSalaComAula.Name = "lblSalaComAula";
            this.lblSalaComAula.Size = new System.Drawing.Size(239, 32);
            this.lblSalaComAula.TabIndex = 256;
            this.lblSalaComAula.Text = "X Salas Com Aula";
            // 
            // lblSalaSemAula
            // 
            this.lblSalaSemAula.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSalaSemAula.AutoSize = true;
            this.lblSalaSemAula.BackColor = System.Drawing.Color.SeaGreen;
            this.lblSalaSemAula.Font = new System.Drawing.Font("KG Second Chances Sketch", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalaSemAula.ForeColor = System.Drawing.Color.White;
            this.lblSalaSemAula.Location = new System.Drawing.Point(818, 218);
            this.lblSalaSemAula.Name = "lblSalaSemAula";
            this.lblSalaSemAula.Size = new System.Drawing.Size(259, 32);
            this.lblSalaSemAula.TabIndex = 257;
            this.lblSalaSemAula.Text = "X Salas Disponiveis";           
            // 
            // FrmVizualizarSala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1103, 621);
            this.Controls.Add(this.lblNehumaSala);
            this.Controls.Add(this.lblSalaSemAula);
            this.Controls.Add(this.lblSalaComAula);
            this.Controls.Add(this.panelSalaDisponivel);
            this.Controls.Add(this.panelAula);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.TopControl);
            this.Controls.Add(this.shapeContainer1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmVizualizarSala";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VizualizarSala";
            this.TopControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDesMaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelAula.ResumeLayout(false);
            this.panelAula.PerformLayout();
            this.panelSalaDisponivel.ResumeLayout(false);
            this.panelSalaDisponivel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblData;
        private System.Windows.Forms.Panel TopControl;
        private System.Windows.Forms.PictureBox btnDesMaximizar;
        private System.Windows.Forms.PictureBox btnMinimizar;
        private System.Windows.Forms.PictureBox btnMaximizar;
        private System.Windows.Forms.PictureBox btnSair;
        private Bunifu.Framework.UI.BunifuThinButton2 lblIFSP;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblHorario;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panelSalaDisponivel;
        public System.Windows.Forms.PictureBox pictureBox2;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel panel1;
        public Bunifu.Framework.UI.BunifuCustomLabel lblSala;
        public System.Windows.Forms.Label label2;
        public Bunifu.Framework.UI.BunifuCustomLabel lblProfessor;
        public System.Windows.Forms.Label label3;
        public Bunifu.Framework.UI.BunifuCustomLabel lblMateria;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        public Bunifu.Framework.UI.BunifuCustomLabel lblHoraInicio;
        public Bunifu.Framework.UI.BunifuCustomLabel lblHoraFim;
        public System.Windows.Forms.Panel panelAula;
        public System.Windows.Forms.Label lblSalaComAula;
        public System.Windows.Forms.Label lblSalaSemAula;
        public Bunifu.Framework.UI.BunifuCustomLabel lblNomeSalasSemAula;
        public System.Windows.Forms.Label lblNehumaSala;
        public System.Windows.Forms.Label lblProximo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
    }
}
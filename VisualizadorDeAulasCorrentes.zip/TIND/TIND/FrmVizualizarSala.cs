﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;


namespace TIND
{
    public partial class FrmVizualizarSala : Form
    {
        public FrmVizualizarSala()
        {
            InitializeComponent();            
            inicio();
            this.Text = "Aulas Ao Vivo";
        }
        
        bool continua = true;

        private async void inicio()
        {
            while (continua)
            {
                if (fila.Count == 0)
                {
                    if (atualizarFila())
                        exibirDadosAula(fila.Dequeue());
                    else
                        configurarPanelAula(0);
                }
                else
                {
                    exibirDadosAula(fila.Dequeue());
                }
                    for (int i = 5; i >= 0; i--)
                    {
                        if (fila.Count() >= 0)
                        {
                            lblProximo.Visible = true;
                            lblProximo.Text = string.Empty;

                            for (int j = 0; j < i; j++)
                                lblProximo.Text += "- ";
                        }
                        else
                            lblProximo.Visible = false;

                        await Task.Delay(1000);
                    }
                
            }
        }    
        
        Queue<int> fila = new Queue<int>();      

        private void configurarPanelAula(int p)
        {
            if (p == 0)
            {
                panelAula.Visible = false;
                lblNehumaSala.Visible = true;
                lblNehumaSala.Location = new Point(118, 100);
            }
            else
            {
                panelAula.Visible = true;
                lblNehumaSala.Visible = false;
                lblNehumaSala.Location = new Point(118, 100);
            }
        }

        private void exibirDadosAula(int id)
        {
            configurarPanelAula(1);

            Conexao conexao = new Conexao();
            try
            {
                conexao.conectar();

                SqlCommand cmd = new SqlCommand("sp_SelAula", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", id);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblSala.Text = dr["Sala"].ToString();
                    lblMateria.Text = dr["Materia"].ToString();
                    lblProfessor.Text = dr["Professor"].ToString();
                    lblHoraInicio.Text = (Convert.ToDateTime(dr["DataInicio"].ToString())).ToShortTimeString();
                    lblHoraFim.Text = (Convert.ToDateTime(dr["DataFim"].ToString())).ToShortTimeString();
                    panelAula.Visible = true;
                }
                dr.Close();
                conexao.desconectar();                                
            }
            catch
            {
                fila.Clear();                
            }                     
        }
        
        private bool atualizarFila()
        {
            bool retorno = false;
            int salasComAula = 0;
            int totalSalas = 0;            

            Conexao conexao = new Conexao();
            try
            {
                conexao.conectar();

                SqlCommand cmd = new SqlCommand("sp_SelIdAula", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pDataAtual", DateTime.Now);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    fila.Enqueue(int.Parse(dr["Id"].ToString()));
                    salasComAula++;
                    retorno = true;
                }

                if(salasComAula > 1)
                    lblSalaComAula.Text = salasComAula.ToString() + " Salas Com Aula";
                else
                    lblSalaComAula.Text = salasComAula.ToString() + " Sala Com Aula";
                
                dr.Close();
                conexao.desconectar();

                conexao.conectar();
                cmd = new SqlCommand("sp_SelIdSala", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    totalSalas = int.Parse(dr["TotalId"].ToString());
                }

                dr.Close();
                conexao.desconectar();

                if (totalSalas - salasComAula > 1)
                    lblSalaSemAula.Text = (totalSalas - salasComAula).ToString() + " Salas Sem Aula";
                else
                    lblSalaSemAula.Text = (totalSalas - salasComAula).ToString() + " Sala Sem Aula";

                if (totalSalas - salasComAula > 0)
                {
                    conexao.conectar(); //sp_SelSalasDispAgora
                    cmd = new SqlCommand("sp_SelSalasDispAgora", conexao.conexao);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@pDataAtual", DateTime.Now);
                    dr = cmd.ExecuteReader();


                    int i = 0;
                    lblNomeSalasSemAula.Text = string.Empty;

                    while (dr.Read())
                    {
                        if (i < 14)
                        {
                            if (i % 7 != 0)
                                lblNomeSalasSemAula.Text += dr["Sala"].ToString() + ",     ";
                            else
                                lblNomeSalasSemAula.Text += "\n\n" + dr["Sala"].ToString() + ",    ";
                            i++;
                        }
                    }
                    dr.Close();
                    conexao.desconectar();
                }
                
                return retorno;
            }
            catch
            {
                fila.Clear();
                return retorno;
            }                       
        }              
      
        private void BtnMaximizar_Click_1(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Maximized;
            btnMaximizar.Visible = false;
            btnDesMaximizar.Visible = true;
            panelAula.Location = new Point(40, 95);

            if (panelAula.Visible == false)
                lblNehumaSala.Visible = true;
        }

        private void BtnMaximizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Normal;
            btnMaximizar.Visible = true;
            btnDesMaximizar.Visible = false;
            panelAula.Location = new Point(23, 88);
            lblNehumaSala.Visible = false;
        }

        private void BtnMinimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }   

        private void Timer1_Tick(object sender, EventArgs e)
        {
            lblData.Text = DateTime.Now.ToString("dd/MM/yyyy");
            lblHorario.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblIFSP_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cpv.ifsp.edu.br/");
        }        
    }
}

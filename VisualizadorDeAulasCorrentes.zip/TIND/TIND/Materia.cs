﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace TIND
{
    class Materia
    {
        private int mId;
        private string mNome;
        private string mAbrev;
        private int mSemestre;
        private string mNomeCurso;
        private int mIdCurso;

        public int id
        {
            get { return mId; }
            set { mId = value; }
        }
        public string nome
        {
            get { return mNome; }
            set { mNome = value; }
        }
        public string abrev
        {
            get { return mAbrev; }
            set { mAbrev = value; }
        }
        public int semestre
        {
            get { return mSemestre; }
            set { mSemestre = value; }
        }
        public string nomeCurso
        {
            get { return mNomeCurso; }
            set { mNomeCurso = value; }
        }
        public int IdCurso
        {
            get { return mIdCurso; }
            set { mIdCurso = value; }
        }

        public static Materia getMateria(int id)
        {
            Conexao conexao = new Conexao();
            try
            {
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_SelMateriaEspecifica", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", Convert.ToInt32(id));
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (dr.Read())
                {
                    Materia umaMateria = new Materia();
                    umaMateria.id = id;
                    umaMateria.nome = dr["Nome"].ToString();
                    umaMateria.abrev = dr["Abrev"].ToString();
                    umaMateria.nomeCurso = dr["Curso"].ToString();
                    umaMateria.IdCurso = int.Parse(dr["IdCurso"].ToString());
                    umaMateria.semestre = int.Parse(dr["Semestre"].ToString());
                    return (umaMateria);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
            finally
            {
                conexao.desconectar();                
            }                          
        }       
        public static string setMateria(Materia materia)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_InsMateria", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pNome", materia.nome);
                cmd.Parameters.AddWithValue("@pAbrev", materia.abrev);
                cmd.Parameters.AddWithValue("@pCurso", materia.IdCurso);
                cmd.Parameters.AddWithValue("@pSemestre", materia.semestre);                
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                conexao.desconectar();
                return ("");
            }
            catch(Exception ex)
            {
                return ex.ToString();
            }
        }
        public static string updMateria(Materia materia)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_UpdMateria", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pNome", materia.nome);
                cmd.Parameters.AddWithValue("@pAbrev", materia.abrev);
                cmd.Parameters.AddWithValue("@pCurso", Convert.ToInt32(materia.nomeCurso));
                cmd.Parameters.AddWithValue("@pSemestre", materia.semestre);
                cmd.Parameters.AddWithValue("@pId", materia.id);
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                conexao.desconectar();
                return ("");
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        public static string delMateria(int id)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_DelMateria", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", id);
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                return ("");
            }
            catch (Exception ex)
            {
                return (ex.ToString());
            }
        }
        public static int maiorSemestre(int id)
        {
            Conexao conexao = new Conexao();
            int maior = 0;
            try
            {
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_SelMaiorSemestre", conexao.conexao);
                cmd.Parameters.AddWithValue("@pId", id);
                cmd.CommandType = CommandType.StoredProcedure;              
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {                  
                    maior = int.Parse(dr["Maior"].ToString());                   
                }
                else
                {
                    maior = 1;
                }
                return maior;
            }
            catch
            {
                return(1);
            }
            finally
            {
                conexao.desconectar();                
            }            
        }
    }
}

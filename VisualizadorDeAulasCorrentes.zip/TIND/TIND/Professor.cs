﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace TIND
{
    class Professor
    {
        private int mId;
        private string mNome;
        private string mRa;        
        private string mEmail;       

        public int id
        {
            get { return mId; }
            set { mId = value; }
        }
        public string nome
        {
            get { return mNome; }
            set { mNome = value; }
        }
        public string ra
        {
            get { return mRa; }
            set { mRa = value; }
        }     
        public string email
        {
            get { return mEmail; }
            set { mEmail = value; }
        }       


        public static Professor getProfessor(int id)
        {
            Conexao conexao = new Conexao();
            try
            {
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_SelProfessorEspecifico", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", Convert.ToInt32(id));
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (dr.Read())
                {
                    Professor professor = new Professor();
                    professor.id = id;
                    professor.nome = dr["Nome"].ToString();
                    professor.email = dr["Email"].ToString();
                    professor.ra = dr["Ra"].ToString();
                    return (professor);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
            finally
            {
                conexao.desconectar();
            }
        }    

        public static string setProfessor(Professor professor)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_InsProfessor", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pNome", professor.nome);
                cmd.Parameters.AddWithValue("@pEmail", professor.email);
                cmd.Parameters.AddWithValue("@pRa", professor.ra);                
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                conexao.desconectar();
                return ("");
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        public static string updProfessor(Professor professor)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_UpdProfessor", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pNome", professor.nome);
                cmd.Parameters.AddWithValue("@pEmail", professor.email);
                cmd.Parameters.AddWithValue("@pRa", professor.ra);                
                cmd.Parameters.AddWithValue("@pId", professor.id);
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                conexao.desconectar();
                return ("");
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        public static string delProfessor(int id)
        {
            try
            {
                Conexao conexao = new Conexao();
                conexao.conectar();
                SqlCommand cmd = new SqlCommand("sp_DelProfessor", conexao.conexao);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", id);
                cmd.ExecuteReader(CommandBehavior.SingleRow);
                return ("");
            }
            catch (Exception ex)
            {
                return (ex.ToString());
            }
        }
    }
}


--CRIA��O DA TABELA PROFESSOR 

CREATE TABLE [dbo].[professor](
	[Id] [int] NOT NULL,
	[nome] [nchar](100) NOT NULL,
	[prontuario] [nchar](7) NOT NULL,
	[email] [nchar](200) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO



-- PROCEDURE DE INSERT  PARA TABELA PROFESSOR


CREATE PROCEDURE SP_InserirProfessor
       @ID AS INT,
       @NOME AS VARCHAR(50),
       @PRONTUARIO AS VARCHAR(9),
       @EMAIL AS VARCHAR(50)

  
AS
BEGIN
       INSERT INTO PROFESSOR (ID,NOME,PRONTUARIO,EMAIL) 
       VALUES (@ID, @NOME, @PRONTUARIO, @EMAIL)
END


-- PROCEDURE DE UPDATE  PARA TABELA PROFESSOR


CREATE PROCEDURE SP_AtualizarProfessor
       @ID AS VARCHAR(50),
       @NOME AS VARCHAR(50),
       @PRONTUARIO AS VARCHAR(9),
       @EMAIL AS VARCHAR(50)

  
AS
BEGIN
       UPDATE PROFESSOR SET NOME=@NOME, PRONTUARIO=@PRONTUARIO, EMAIL=@EMAIL WHERE ID=@ID
END


-- PROCEDURE DE DELETE  PARA TABELA PROFESSOR


  
CREATE PROCEDURE SP_ExcluirProfessor
       @ID AS INT
AS
BEGIN
       DELETE FROM PROFESSOR WHERE ID=@ID
END


-- PROCEDURE DE SELECT  PARA TABELA PROFESSOR


CREATE PROCEDURE SP_SelecionarProfessor
       @ID AS INT
AS
BEGIN
       SELECT * FROM PROFESSOR WHERE ID=@ID
END





----------------------------------------------------------------------------------------------------------------------------------------


--CRIA��O DA TABELA MATERIA 


CREATE TABLE [dbo].[Materia](
	[Id] [int] NOT NULL,
	[nome] [nchar](100) NOT NULL,
	[abrev] [nchar](7) NOT NULL,
	[email] [nchar](200) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


-- PROCEDURE DE INSERT  PARA TABELA MATERIA


CREATE PROCEDURE SP_InserirMateria
       @ID AS INT,
       @NOME AS VARCHAR(50),
       @ABREV AS VARCHAR(9),
       @CURSO AS VARCHAR(50)
  
AS
BEGIN
       INSERT INTO MATERIA (ID,NOME,ABREV,CURSO) 
       VALUES (@ID, @NOME, @ABREV, @CURSO)
END


-- PROCEDURE DE UPDATE  PARA TABELA MATERIA


CREATE PROCEDURE SP_AtualizarMateria
       @ID AS INT,
       @NOME AS VARCHAR(50),
       @ABREV AS VARCHAR(9),
       @CURSO AS VARCHAR(50)

  
AS
BEGIN
       UPDATE MATERIA SET NOME=@NOME, ABREV=@ABREV, CURSO=@CURSO WHERE ID=@ID
END


-- PROCEDURE DE DELETE PARA TB MATERIA


  
CREATE PROCEDURE SP_ExcluirMateria
       @ID AS INT
AS
BEGIN
       DELETE FROM MATERIA WHERE ID=@ID
END


-- PROCEDURE DE SELECT PARA TABELA MAT�RIA


CREATE PROCEDURE SP_SelecionarMateria
       @ID AS INT
AS
BEGIN
       SELECT * FROM MATERIA WHERE ID=@ID
END


----------------------------------------------------------------------------------------------------------------------------------------